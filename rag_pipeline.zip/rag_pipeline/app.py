import os
import sys
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).parent))

from src.chain import build_chain, collection_exists, get_sources
from src.config import CDP_COMPONENTS

# ── Page config ──────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="CDP Docs Assistant",
    page_icon="☁️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────

st.markdown(
    """
<style>
    /* ── Global ── */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    .stApp {
        background-color: #0F1117;
        color: #E2E8F0;
    }

    /* ── Sidebar ── */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #111827 0%, #0F1117 100%);
        border-right: 1px solid #1E293B;
        padding-top: 0;
    }

    [data-testid="stSidebar"] .block-container {
        padding-top: 1rem;
    }

    /* ── Component cards ── */
    .component-card {
        border-radius: 10px;
        padding: 12px 14px;
        margin-bottom: 8px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: all 0.2s ease;
    }

    .component-card.active {
        background: linear-gradient(135deg, #064E3B 0%, #065F46 100%);
        border-color: #00A591;
    }

    .component-card.coming-soon {
        background: #1E293B;
        border-color: #334155;
        opacity: 0.6;
    }

    .component-card .card-title {
        font-weight: 600;
        font-size: 13px;
        color: #F1F5F9;
    }

    .component-card .card-desc {
        font-size: 11px;
        color: #94A3B8;
        margin-top: 2px;
    }

    .badge-active {
        background: #00A591;
        color: white;
        font-size: 9px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 20px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .badge-soon {
        background: #334155;
        color: #64748B;
        font-size: 9px;
        font-weight: 600;
        padding: 2px 7px;
        border-radius: 20px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* ── Chat messages ── */
    .chat-user {
        background: #1E40AF;
        color: #EFF6FF;
        padding: 14px 18px;
        border-radius: 16px 16px 4px 16px;
        margin: 8px 0 8px 60px;
        font-size: 14px;
        line-height: 1.6;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }

    .chat-assistant {
        background: #1E293B;
        color: #E2E8F0;
        padding: 14px 18px;
        border-radius: 16px 16px 16px 4px;
        margin: 8px 60px 8px 0;
        font-size: 14px;
        line-height: 1.6;
        border-left: 3px solid #00A591;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }

    /* ── Source citation cards ── */
    .source-card {
        background: #0F2231;
        border: 1px solid #1E3A5F;
        border-radius: 8px;
        padding: 10px 14px;
        margin-top: 6px;
        font-size: 12px;
    }

    .source-card .src-header {
        color: #38BDF8;
        font-weight: 600;
        font-size: 12px;
    }

    .source-card .src-excerpt {
        color: #94A3B8;
        margin-top: 4px;
        font-size: 11px;
        line-height: 1.5;
    }

    /* ── Input box ── */
    .stTextInput > div > div > input, .stChatInput textarea {
        background: #1E293B !important;
        border: 1px solid #334155 !important;
        color: #E2E8F0 !important;
        border-radius: 12px !important;
    }

    /* ── Divider ── */
    hr {
        border-color: #1E293B !important;
        margin: 16px 0;
    }

    /* ── Header ── */
    .app-header {
        text-align: center;
        padding: 24px 0 8px 0;
    }

    .app-header h1 {
        font-size: 28px;
        font-weight: 700;
        color: #F8FAFC;
        margin: 0;
    }

    .app-header p {
        font-size: 14px;
        color: #64748B;
        margin-top: 4px;
    }

    .selected-component-banner {
        background: linear-gradient(90deg, #064E3B, #065F46);
        border: 1px solid #00A591;
        border-radius: 10px;
        padding: 10px 16px;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .selected-component-banner .comp-name {
        font-weight: 600;
        font-size: 15px;
        color: #A7F3D0;
    }

    .selected-component-banner .comp-desc {
        font-size: 12px;
        color: #6EE7B7;
    }

    /* ── No-index warning ── */
    .not-indexed-warning {
        background: #1C1400;
        border: 1px solid #92400E;
        border-radius: 10px;
        padding: 14px 18px;
        color: #FCD34D;
        font-size: 13px;
    }

    /* ── Scrollbar ── */
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: #0F1117; }
    ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
</style>
""",
    unsafe_allow_html=True,
)

# ── Session state ─────────────────────────────────────────────────────────────

if "messages" not in st.session_state:
    st.session_state.messages = []
if "selected_component" not in st.session_state:
    st.session_state.selected_component = "cod"
if "chain" not in st.session_state:
    st.session_state.chain = None
if "retriever" not in st.session_state:
    st.session_state.retriever = None

# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown(
        """
        <div style='text-align:center; padding: 16px 0 20px 0;'>
            <span style='font-size:36px;'>☁️</span>
            <div style='font-size:16px; font-weight:700; color:#F8FAFC; margin-top:6px;'>CDP Docs Assistant</div>
            <div style='font-size:11px; color:#475569; margin-top:2px;'>Cloudera Public Cloud · RAG-Powered</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        "<div style='font-size:11px; font-weight:600; color:#475569; text-transform:uppercase; letter-spacing:1px; margin-bottom:10px;'>CDP Components</div>",
        unsafe_allow_html=True,
    )

    for key, comp in CDP_COMPONENTS.items():
        is_active = comp["status"] == "active"
        is_selected = st.session_state.selected_component == key

        card_class = "active" if is_active else "coming-soon"
        badge_html = (
            '<span class="badge-active">Active</span>'
            if is_active
            else '<span class="badge-soon">Coming Soon</span>'
        )

        selected_style = "outline: 2px solid #00A591;" if is_selected and is_active else ""

        st.markdown(
            f"""
            <div class="component-card {card_class}" style="{selected_style}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div class="card-title">{comp['icon']} {comp['name']}</div>
                    {badge_html}
                </div>
                <div class="card-desc">{comp['description']}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        if is_active:
            if st.button(
                f"Select {comp['name']}",
                key=f"btn_{key}",
                use_container_width=True,
                type="primary" if is_selected else "secondary",
            ):
                st.session_state.selected_component = key
                st.session_state.chain = None
                st.session_state.retriever = None
                st.session_state.messages = []
                st.rerun()

    st.markdown("<hr>", unsafe_allow_html=True)

    st.markdown(
        "<div style='font-size:11px; font-weight:600; color:#475569; text-transform:uppercase; letter-spacing:1px; margin-bottom:8px;'>Model Config</div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        """
        <div style='font-size:12px; color:#64748B; line-height:1.8;'>
            🧠 <b style='color:#94A3B8;'>LLM</b>: GPT-4o Mini<br>
            📐 <b style='color:#94A3B8;'>Embeddings</b>: text-embedding-3-small<br>
            🗃️ <b style='color:#94A3B8;'>Vector DB</b>: ChromaDB (local)<br>
            🔍 <b style='color:#94A3B8;'>Search</b>: MMR (top-5)
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("<hr>", unsafe_allow_html=True)

    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ── Main area ─────────────────────────────────────────────────────────────────

st.markdown(
    """
    <div class="app-header">
        <h1>☁️ CDP Documentation Assistant</h1>
        <p>Ask anything about Cloudera Data Platform — powered by official product documentation</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("<hr>", unsafe_allow_html=True)

# Active component banner
comp = CDP_COMPONENTS[st.session_state.selected_component]
st.markdown(
    f"""
    <div class="selected-component-banner">
        <span style="font-size:24px;">{comp['icon']}</span>
        <div>
            <div class="comp-name">{comp['name']}</div>
            <div class="comp-desc">{comp['description']}</div>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# ── Load chain ────────────────────────────────────────────────────────────────

component_key = st.session_state.selected_component
indexed = collection_exists(component_key)

if indexed and st.session_state.chain is None:
    with st.spinner("Loading knowledge base..."):
        chain, retriever = build_chain(component_key)
        st.session_state.chain = chain
        st.session_state.retriever = retriever

# ── Not indexed warning ───────────────────────────────────────────────────────

if not indexed:
    st.markdown(
        f"""
        <div class="not-indexed-warning">
            ⚠️ <b>No indexed documents found</b> for <b>{comp['name']}</b>.<br><br>
            Drop your PDF files into <code>data/pdfs/{comp['folder']}/</code> and run:<br>
            <code style='background:#2D1A00; padding:4px 8px; border-radius:4px; display:inline-block; margin-top:6px;'>
                python -m src.ingest --component {component_key}
            </code>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.stop()

# ── Render chat history ───────────────────────────────────────────────────────

for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.markdown(
            f'<div class="chat-user">👤 {msg["content"]}</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f'<div class="chat-assistant">🤖 {msg["content"]}</div>',
            unsafe_allow_html=True,
        )
        if msg.get("sources"):
            with st.expander(f"📄 View {len(msg['sources'])} source(s)", expanded=False):
                for i, src in enumerate(msg["sources"], 1):
                    st.markdown(
                        f"""
                        <div class="source-card">
                            <div class="src-header">📄 Source {i} — {src['file']} · Page {src['page']}</div>
                            <div class="src-excerpt">{src['excerpt']}</div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

# ── Chat input ────────────────────────────────────────────────────────────────

if prompt := st.chat_input(f"Ask about {comp['name']}..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.markdown(
        f'<div class="chat-user">👤 {prompt}</div>',
        unsafe_allow_html=True,
    )

    sources = get_sources(st.session_state.retriever, prompt)

    response_placeholder = st.empty()
    full_response = ""

    with st.spinner("Searching documentation..."):
        with response_placeholder.container():
            response_box = st.empty()
            for chunk in st.session_state.chain.stream(prompt):
                full_response += chunk
                response_box.markdown(
                    f'<div class="chat-assistant">🤖 {full_response}▌</div>',
                    unsafe_allow_html=True,
                )

    response_placeholder.empty()
    st.markdown(
        f'<div class="chat-assistant">🤖 {full_response}</div>',
        unsafe_allow_html=True,
    )

    if sources:
        with st.expander(f"📄 View {len(sources)} source(s)", expanded=False):
            for i, src in enumerate(sources, 1):
                st.markdown(
                    f"""
                    <div class="source-card">
                        <div class="src-header">📄 Source {i} — {src['file']} · Page {src['page']}</div>
                        <div class="src-excerpt">{src['excerpt']}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    st.session_state.messages.append(
        {"role": "assistant", "content": full_response, "sources": sources}
    )
