"""
RAG chain: question → retrieval → LLM answer with cited sources
"""

from langchain_chroma import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from src.config import EMBEDDING_MODEL, LLM_MODEL, RETRIEVAL_TOP_K, VECTORSTORE_DIR

SYSTEM_PROMPT = """You are an expert assistant for Cloudera Data Platform (CDP) Public Cloud documentation.
Answer the user's question using ONLY the provided context from the official CDP documentation.

Rules:
- Be precise and technical. Use CDP-specific terminology correctly.
- If the context does not contain enough information to answer, say so clearly — do not hallucinate.
- Structure longer answers with bullet points or numbered steps where appropriate.
- Always refer to the source document when making specific claims.

Context:
{context}
"""

HUMAN_PROMPT = "{question}"


def _format_docs(docs) -> str:
    parts = []
    for i, doc in enumerate(docs, start=1):
        meta = doc.metadata
        header = f"[Source {i}: {meta.get('source', 'unknown')}, Page {meta.get('page', '?')}]"
        parts.append(f"{header}\n{doc.page_content}")
    return "\n\n---\n\n".join(parts)


def get_vectorstore(component_key: str) -> Chroma:
    embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
    return Chroma(
        collection_name=f"cdp_{component_key}",
        embedding_function=embeddings,
        persist_directory=str(VECTORSTORE_DIR),
    )


def build_chain(component_key: str):
    vectorstore = get_vectorstore(component_key)
    retriever = vectorstore.as_retriever(
        search_type="mmr",  # maximal marginal relevance for diversity
        search_kwargs={"k": RETRIEVAL_TOP_K, "fetch_k": RETRIEVAL_TOP_K * 3},
    )

    prompt = ChatPromptTemplate.from_messages(
        [("system", SYSTEM_PROMPT), ("human", HUMAN_PROMPT)]
    )

    llm = ChatOpenAI(model=LLM_MODEL, temperature=0, streaming=True)

    chain = (
        {"context": retriever | _format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    return chain, retriever


def get_sources(retriever, question: str) -> list[dict]:
    docs = retriever.invoke(question)
    sources = []
    seen = set()
    for doc in docs:
        meta = doc.metadata
        key = (meta.get("source"), meta.get("page"))
        if key not in seen:
            seen.add(key)
            subfolder = meta.get("subfolder", "")
            file_label = f"{subfolder}/{meta.get('source', 'unknown')}" if subfolder else meta.get("source", "unknown")
            sources.append(
                {
                    "file": file_label,
                    "page": meta.get("page", "?"),
                    "component": meta.get("component_name", ""),
                    "excerpt": doc.page_content[:300] + "...",
                }
            )
    return sources


def collection_exists(component_key: str) -> bool:
    try:
        vs = get_vectorstore(component_key)
        return vs._collection.count() > 0
    except Exception:
        return False
