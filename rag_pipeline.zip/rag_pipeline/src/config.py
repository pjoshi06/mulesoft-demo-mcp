from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
PDF_DIR = BASE_DIR / "data" / "pdfs"
VECTORSTORE_DIR = BASE_DIR / "vectorstore"

CHUNK_SIZE = 1000
CHUNK_OVERLAP = 150
RETRIEVAL_TOP_K = 5

EMBEDDING_MODEL = "text-embedding-3-small"
LLM_MODEL = "gpt-4o-mini"

CDP_COMPONENTS = {
    "cod": {
        "name": "Operational Database (COD)",
        "folder": "cod",
        "status": "active",
        "description": "HBase-based low-latency operational database on CDP Public Cloud",
        "icon": "🗄️",
        "color": "#00A591",
    },
    "data_lake": {
        "name": "Data Lake",
        "folder": "data_lake",
        "status": "coming_soon",
        "description": "Secure, governed data lake powered by SDX",
        "icon": "🏞️",
        "color": "#6B7280",
    },
    "data_hub": {
        "name": "Data Hub",
        "folder": "data_hub",
        "status": "coming_soon",
        "description": "Elastic clusters for analytics and data engineering",
        "icon": "⚙️",
        "color": "#6B7280",
    },
    "freeipa": {
        "name": "FreeIPA",
        "folder": "freeipa",
        "status": "coming_soon",
        "description": "Identity management and Kerberos authentication",
        "icon": "🔐",
        "color": "#6B7280",
    },
    "cdw": {
        "name": "Data Warehouse (CDW)",
        "folder": "cdw",
        "status": "coming_soon",
        "description": "Cloud-native Hive and Impala data warehouse",
        "icon": "🏢",
        "color": "#6B7280",
    },
    "cml": {
        "name": "Machine Learning (CML)",
        "folder": "cml",
        "status": "coming_soon",
        "description": "Collaborative ML workspace with MLOps capabilities",
        "icon": "🤖",
        "color": "#6B7280",
    },
    "cdf": {
        "name": "DataFlow (CDF)",
        "folder": "cdf",
        "status": "active",
        "description": "Apache NiFi-based data flow management",
        "icon": "🌊",
        "color": "#6B7280",
    },
    "management_console": {
        "name": "Management Console",
        "folder": "management_console",
        "status": "active",
        "description": "Central control plane for CDP environments",
        "icon": "🖥️",
        "color": "#6B7280",
    },
    "cdp_runtime_731": {
        "name": "CDP Runtime 7.3.1",
        "folder": "cdp_runtime_731",
        "status": "active",
        "description": "Cloudera Data Platform Runtime 7.3.1 — core platform components",
        "icon": "⚡",
        "color": "#00A591",
    },
}

ACTIVE_COMPONENTS = {k: v for k, v in CDP_COMPONENTS.items() if v["status"] == "active"}
