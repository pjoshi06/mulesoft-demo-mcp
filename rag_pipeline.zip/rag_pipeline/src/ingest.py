"""
Ingestion pipeline: PDF → chunks → embeddings → ChromaDB
Run directly: python -m src.ingest --component cod
"""

import argparse
import sys
from pathlib import Path

import fitz  # PyMuPDF
from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter

load_dotenv()
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings

from src.config import (
    CDP_COMPONENTS,
    CHUNK_OVERLAP,
    CHUNK_SIZE,
    EMBEDDING_MODEL,
    PDF_DIR,
    VECTORSTORE_DIR,
)


def extract_pages(pdf_path: Path) -> list[dict]:
    doc = fitz.open(str(pdf_path))
    pages = []
    for page_num, page in enumerate(doc, start=1):
        text = page.get_text("text").strip()
        if text:
            pages.append({"text": text, "page": page_num, "source": pdf_path.name})
    doc.close()
    return pages


def load_component_pdfs(component_key: str) -> list[dict]:
    component = CDP_COMPONENTS[component_key]
    pdf_folder = PDF_DIR / component["folder"]

    if not pdf_folder.exists():
        print(f"[warn] Folder not found: {pdf_folder}")
        return []

    pdfs = list(pdf_folder.rglob("*.pdf"))
    if not pdfs:
        print(f"[warn] No PDFs found in {pdf_folder}")
        return []

    all_pages = []
    for pdf_path in pdfs:
        relative = pdf_path.relative_to(pdf_folder)
        print(f"  Extracting: {relative}")
        pages = extract_pages(pdf_path)
        subfolder = pdf_path.parent.name if pdf_path.parent != pdf_folder else ""
        for p in pages:
            p["component"] = component_key
            p["component_name"] = component["name"]
            p["subfolder"] = subfolder
        all_pages.extend(pages)

    print(f"  Extracted {len(all_pages)} pages from {len(pdfs)} PDF(s)")
    return all_pages


def chunk_pages(pages: list[dict]) -> list[dict]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    chunks = []
    for page in pages:
        splits = splitter.split_text(page["text"])
        for i, split in enumerate(splits):
            chunks.append(
                {
                    "text": split,
                    "metadata": {
                        "component": page["component"],
                        "component_name": page["component_name"],
                        "source": page["source"],
                        "subfolder": page.get("subfolder", ""),
                        "page": page["page"],
                        "chunk_index": i,
                    },
                }
            )
    return chunks


def ingest_component(component_key: str, reset: bool = False):
    if component_key not in CDP_COMPONENTS:
        print(f"[error] Unknown component: {component_key}")
        sys.exit(1)

    component = CDP_COMPONENTS[component_key]
    print(f"\nIngesting: {component['name']}")

    pages = load_component_pdfs(component_key)
    if not pages:
        return

    chunks = chunk_pages(pages)
    print(f"  Created {len(chunks)} chunks")

    embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
    vectorstore = Chroma(
        collection_name=f"cdp_{component_key}",
        embedding_function=embeddings,
        persist_directory=str(VECTORSTORE_DIR),
    )

    if reset:
        vectorstore.delete_collection()
        vectorstore = Chroma(
            collection_name=f"cdp_{component_key}",
            embedding_function=embeddings,
            persist_directory=str(VECTORSTORE_DIR),
        )

    texts = [c["text"] for c in chunks]
    metadatas = [c["metadata"] for c in chunks]

    batch_size = 100
    for i in range(0, len(texts), batch_size):
        vectorstore.add_texts(
            texts=texts[i : i + batch_size],
            metadatas=metadatas[i : i + batch_size],
        )
        print(f"  Indexed batch {i // batch_size + 1}/{(len(texts) - 1) // batch_size + 1}")

    print(f"  Done. Collection 'cdp_{component_key}' ready in {VECTORSTORE_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest CDP PDF docs into ChromaDB")
    parser.add_argument("--component", required=True, help="Component key (e.g. cod)")
    parser.add_argument("--reset", action="store_true", help="Delete existing collection before ingesting")
    args = parser.parse_args()
    ingest_component(args.component, reset=args.reset)
