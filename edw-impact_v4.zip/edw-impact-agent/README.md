# EDW Impact Analysis Agent — Hackathon PoC

Demonstrates an AI agent that:
1. Parses SQL scripts to auto-extract column-level metadata
2. Builds a lineage graph across EDW → EDL → ODS
3. Simulates any EDW change and traces downstream impact
4. Answers natural language questions about the pipeline

## Quick Start (2 commands)

### 1. Install backend dependencies (once)
```bash
pip install fastapi uvicorn sqlglot python-multipart
```

### 2. Start everything
```bash
chmod +x start.sh && ./start.sh
```

Then open **http://localhost:5173** in your browser.

---

## Manual Start

**Terminal 1 — Backend:**
```bash
cd backend
uvicorn main:app --reload --port 8000
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm run dev
```

---

## Demo Flow (for judges)

### Tab 1: SQL Metadata
- Click **Load** on any sample script — watch tables and columns populate instantly
- Or upload your own `.sql` file
- Click a table to inspect its columns and transformation types

### Tab 2: Lineage Graph
- See the full EDW → EDL → ODS dependency graph
- Hover any node for details

### Tab 3: Impact Simulator
- Select **EDW.CUSTOMER** → column **RISK_SCORE** → change type **Drop Column**
- Hit **Run Impact Analysis**
- See blast radius, affected columns, and AI-generated remediation advice

### Tab 4: AI Q&A
- Ask: *"What breaks if I drop EDW.CUSTOMER.risk_score?"*
- Ask: *"What does EDL.TRANSACTION_SUMMARY depend on?"*
- Ask: *"Which tables are most critical?"*

---

## Architecture

```
SQL Scripts
    │
    ▼
FastAPI Backend (Python)
├── sqlglot parser        → extracts table/column lineage
├── In-memory graph       → BFS for downstream impact
├── Mock AI reasoning     → generates impact explanation
└── REST API              → /api/tables, /api/lineage, /api/impact, /api/nlquery
    │
    ▼
React Frontend
├── Tab 1: SQL Upload & Metadata store viewer
├── Tab 2: D3.js lineage graph
├── Tab 3: Impact simulator with severity scoring
└── Tab 4: NL Q&A chatbot
```

## Pre-loaded Sample Tables
| Table | Layer | Sources |
|-------|-------|---------|
| EDL.CUSTOMER_PROFILE | EDL | EDW.CUSTOMER, EDW.ACCOUNT |
| EDL.TRANSACTION_SUMMARY | EDL | EDW.TRANSACTION, EDW.ACCOUNT, EDW.CUSTOMER |
| ODS.RISK_EXPOSURE | ODS | EDL.CUSTOMER_PROFILE, EDL.TRANSACTION_SUMMARY |
| ODS.CHANNEL_ANALYTICS | ODS | EDL.TRANSACTION_SUMMARY |
