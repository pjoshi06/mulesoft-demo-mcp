from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlglot
from sqlglot import exp
import re
from collections import defaultdict, deque

app = FastAPI(title="EDW Impact Analysis Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── IN-MEMORY STORE ───────────────────────────────────────────────────────────
metadata_store = {}   # table_name -> { columns, source_tables, layer, sql }
lineage_graph  = {}   # table_name -> { source_tables, columns }

# ─── SAMPLE SCRIPTS ────────────────────────────────────────────────────────────
SAMPLE_SCRIPTS = {
    "edl_customer_profile.sql": """
CREATE TABLE EDL.CUSTOMER_PROFILE AS
SELECT
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.date_of_birth,
    c.country_code,
    a.account_id,
    a.account_type,
    a.account_status,
    a.open_date,
    COALESCE(a.credit_limit, 0)        AS credit_limit,
    CAST(c.risk_score AS DECIMAL(5,2)) AS risk_score
FROM EDW.CUSTOMER c
JOIN EDW.ACCOUNT a ON c.customer_id = a.customer_id
WHERE a.account_status = 'ACTIVE';
""",
    "edl_transaction_summary.sql": """
CREATE TABLE EDL.TRANSACTION_SUMMARY AS
SELECT
    t.transaction_id,
    t.account_id,
    t.transaction_date,
    t.transaction_type,
    t.amount,
    t.currency_code,
    UPPER(t.channel)   AS channel,
    c.customer_id,
    c.country_code     AS customer_country,
    CASE
        WHEN t.amount > 10000 THEN 'HIGH'
        WHEN t.amount > 1000  THEN 'MEDIUM'
        ELSE 'LOW'
    END                AS amount_tier
FROM EDW.TRANSACTION t
JOIN EDW.ACCOUNT   a ON t.account_id  = a.account_id
JOIN EDW.CUSTOMER  c ON a.customer_id = c.customer_id;
""",
    "ods_risk_exposure.sql": """
CREATE TABLE ODS.RISK_EXPOSURE AS
SELECT
    cp.customer_id,
    cp.first_name,
    cp.last_name,
    cp.risk_score,
    cp.credit_limit,
    cp.account_type,
    SUM(ts.amount)              AS total_exposure,
    COUNT(ts.transaction_id)    AS transaction_count,
    MAX(ts.transaction_date)    AS last_transaction_date,
    COALESCE(cp.country_code, 'UNKNOWN') AS country_code
FROM EDL.CUSTOMER_PROFILE cp
LEFT JOIN EDL.TRANSACTION_SUMMARY ts ON cp.account_id = ts.account_id
GROUP BY cp.customer_id, cp.first_name, cp.last_name,
         cp.risk_score, cp.credit_limit, cp.account_type, cp.country_code;
""",
    "ods_channel_analytics.sql": """
CREATE TABLE ODS.CHANNEL_ANALYTICS AS
SELECT
    ts.channel,
    ts.currency_code,
    ts.amount_tier,
    ts.customer_country,
    COUNT(ts.transaction_id) AS transaction_count,
    SUM(ts.amount)           AS total_amount,
    AVG(ts.amount)           AS avg_amount,
    MAX(ts.transaction_date) AS latest_date
FROM EDL.TRANSACTION_SUMMARY ts
GROUP BY ts.channel, ts.currency_code, ts.amount_tier, ts.customer_country;
"""
}

# ─── SQL PARSER ────────────────────────────────────────────────────────────────
def parse_sql(sql: str, filename: str = "unknown.sql") -> dict:
    result = {
        "target_table": None,
        "source_tables": [],
        "columns": [],
        "layer": "UNKNOWN",
        "sql": sql.strip(),
        "filename": filename
    }
    try:
        statements = sqlglot.parse(sql, error_level=sqlglot.ErrorLevel.IGNORE)
        for stmt in statements:
            if stmt is None:
                continue
            # Target table
            if isinstance(stmt, exp.Create):
                tbl_expr = stmt.this
                if isinstance(tbl_expr, exp.Schema):
                    tbl_expr = tbl_expr.this
                if isinstance(tbl_expr, exp.Table):
                    db = tbl_expr.args.get("db")
                    name = tbl_expr.name
                    result["target_table"] = (f"{db.name}.{name}" if db else name).upper()

            if result["target_table"]:
                if result["target_table"].startswith("EDL."): result["layer"] = "EDL"
                elif result["target_table"].startswith("ODS."): result["layer"] = "ODS"
                elif result["target_table"].startswith("EDW."): result["layer"] = "EDW"

            source_set = set()
            for tbl in stmt.find_all(exp.Table):
                db = tbl.args.get("db")
                name = tbl.name
                full = (f"{db.name}.{name}" if db else name).upper()
                if full != result["target_table"] and full:
                    source_set.add(full)
            result["source_tables"] = list(source_set)

            select = stmt.find(exp.Select)
            if select:
                for sel in select.expressions:
                    col_info = _extract_col(sel)
                    if col_info:
                        result["columns"].append(col_info)
    except Exception as e:
        result["parse_error"] = str(e)
    return result


def _extract_col(sel_expr) -> Optional[dict]:
    try:
        alias = getattr(sel_expr, "alias", None)
        inner = sel_expr.this if alias else sel_expr
        col_name = (alias or (inner.name if hasattr(inner, "name") else str(inner))).upper()
        if not col_name or col_name in ("*", ""):
            return None
        transform = "DIRECT"
        if isinstance(inner, exp.Cast): transform = "CAST"
        elif isinstance(inner, exp.Coalesce): transform = "COALESCE"
        elif isinstance(inner, exp.Case): transform = "CASE"
        elif isinstance(inner, (exp.Sum, exp.Count, exp.Max, exp.Min, exp.Avg)): transform = "AGGREGATE"
        elif isinstance(inner, (exp.Upper, exp.Lower, exp.Anonymous)): transform = "FUNCTION"
        sources = []
        for col in inner.find_all(exp.Column):
            tbl_alias = col.table.upper() if col.table else None
            col_n     = col.name.upper() if col.name else None
            if col_n:
                sources.append({"table_alias": tbl_alias, "column": col_n})
        return {"name": col_name, "transform": transform, "source_columns": sources}
    except Exception:
        return None


def extract_cte_names(sql: str) -> set:
    """Return the set of CTE names defined in WITH clauses (case-insensitive)."""
    cte_names = set()
    for m in re.finditer(r'WITH\s+(\w+)\s+AS\s*\(', sql, re.IGNORECASE):
        cte_names.add(m.group(1).upper())
    # also catch comma-separated CTEs: , cte_name AS (
    for m in re.finditer(r',\s*(\w+)\s+AS\s*\(', sql, re.IGNORECASE):
        cte_names.add(m.group(1).upper())
    return cte_names


def resolve_cte_sources(cte_name: str, sql: str) -> list:
    """
    Given a CTE name, find which real tables it reads from.
    Returns a list of real table names (schema.table format).
    """
    # Find the CTE body between its AS ( ... )
    pattern = re.compile(
        r'(?:WITH|,)\s+' + re.escape(cte_name) + r'\s+AS\s*\(',
        re.IGNORECASE
    )
    m = pattern.search(sql)
    if not m:
        return []

    # Extract the CTE body by counting parentheses
    start = m.end()
    depth = 1
    pos = start
    while pos < len(sql) and depth > 0:
        if sql[pos] == '(': depth += 1
        elif sql[pos] == ')': depth -= 1
        pos += 1
    cte_body = sql[start:pos - 1]

    # Find all FROM / JOIN references inside the CTE body
    real_tables = []
    for tm in re.finditer(r'(?:FROM|JOIN)\s+([\w]+\.[\w]+|[\w]+)\s*(?:(?:AS\s+)?\w+)?', cte_body, re.IGNORECASE):
        tbl = tm.group(1).upper()
        # Only keep schema-qualified names (EDW.*, EDL.*, ODS.*) as real tables
        if '.' in tbl:
            real_tables.append(tbl)
    return real_tables


def resolve_aliases(parsed: dict, sql: str) -> dict:
    """
    1. Build alias map from FROM/JOIN clauses (e.g. c -> EDW.CUSTOMER)
    2. Detect CTE names so we can skip them as fake source tables
    3. For columns sourced from a CTE alias, resolve to the real EDW table
    """
    cte_names = extract_cte_names(sql)

    # Map: alias -> real table name
    alias_map = {}
    for m in re.finditer(r'(?:FROM|JOIN)\s+([\w.]+)\s+(?:AS\s+)?(\w+)', sql, re.IGNORECASE):
        full_tbl = m.group(1).upper()
        alias    = m.group(2).upper()
        alias_map[alias] = full_tbl

    # Build CTE -> [real source tables] map
    cte_sources = {}
    for cte in cte_names:
        cte_sources[cte] = resolve_cte_sources(cte, sql)

    # Resolve each column's source_columns
    for col in parsed.get("columns", []):
        for src in col.get("source_columns", []):
            alias = src.get("table_alias")
            if not alias:
                src["source_table"] = None
                continue

            resolved = alias_map.get(alias, alias)

            # If the resolved name is a CTE, replace it with the CTE's real sources
            # We pick the first real source table for display purposes
            if resolved in cte_names or alias in cte_names:
                cte_key = alias if alias in cte_names else resolved
                real_sources = cte_sources.get(cte_key, [])
                src["source_table"] = real_sources[0] if real_sources else resolved
                src["via_cte"] = cte_key  # keep for traceability
            else:
                src["source_table"] = resolved

    # Also clean up source_tables list: replace CTE names with their real tables
    cleaned_sources = []
    for s in parsed.get("source_tables", []):
        if s in cte_names:
            cleaned_sources.extend(cte_sources.get(s, []))
        elif s not in cte_names:
            cleaned_sources.append(s)
    # Deduplicate while preserving order
    seen = set()
    deduped = []
    for s in cleaned_sources:
        if s not in seen:
            seen.add(s)
            deduped.append(s)
    parsed["source_tables"] = deduped

    return parsed


def store_parsed(parsed: dict):
    target = parsed.get("target_table")
    if not target:
        return
    metadata_store[target] = {
        "table": target,
        "layer": parsed.get("layer", "UNKNOWN"),
        "source_tables": parsed.get("source_tables", []),
        "columns": parsed.get("columns", []),
        "sql": parsed.get("sql", ""),
        "filename": parsed.get("filename", "")
    }
    lineage_graph[target] = {
        "source_tables": parsed.get("source_tables", []),
        "columns": {
            col["name"]: {"transform": col["transform"], "sources": col.get("source_columns", [])}
            for col in parsed.get("columns", [])
        }
    }

# ─── IMPACT HELPERS ────────────────────────────────────────────────────────────
def find_downstream_tables(start_table: str) -> list:
    affected, visited, queue = [], set(), deque([start_table.upper()])
    while queue:
        current = queue.popleft()
        for tbl, info in lineage_graph.items():
            if current in info.get("source_tables", []) and tbl not in visited:
                visited.add(tbl); affected.append(tbl); queue.append(tbl)
    return affected


def find_affected_columns(source_table: str, source_column: str) -> list:
    results = []
    st, sc = source_table.upper(), source_column.upper()
    for tbl, info in lineage_graph.items():
        for col_name, col_data in info.get("columns", {}).items():
            for src in col_data.get("sources", []):
                if src.get("source_table") == st and src.get("column") == sc:
                    results.append({
                        "table": tbl, "column": col_name,
                        "transform": col_data.get("transform", "DIRECT"),
                        "layer": metadata_store.get(tbl, {}).get("layer", "?")
                    })
    return results


def mock_ai_explanation(change_type, source_table, source_column, affected, affected_cols):
    n_tables, n_cols = len(affected), len(affected_cols)
    severity  = "HIGH" if n_tables >= 3 else "MEDIUM" if n_tables >= 1 else "LOW"
    agg_cols  = [c for c in affected_cols if c["transform"] == "AGGREGATE"]
    cast_cols = [c for c in affected_cols if c["transform"] == "CAST"]
    coalesce_cols = [c for c in affected_cols if c["transform"] == "COALESCE"]
    tbl_list  = ", ".join(affected[:5]) + ("..." if n_tables > 5 else "")

    agg_note  = f" Aggregate columns ({', '.join([c['column'] for c in agg_cols[:2]])}) will produce incorrect totals or fail entirely." if agg_cols else ""
    cast_note = f" CAST operations on this column may throw type conversion errors in {', '.join([c['column'] for c in cast_cols[:2]])}." if cast_cols else ""
    coal_note = f" {len(coalesce_cols)} COALESCE-wrapped column(s) have partial protection but verify default values are acceptable." if coalesce_cols else ""

    templates = {
        "drop_column": f"""SEVERITY: {severity}

The column `{source_column}` in `{source_table}` is referenced by {n_cols} downstream column(s) across {n_tables} table(s): {tbl_list or 'none'}.

Dropping this column will cause immediate pipeline failures. All ETL jobs reading `{source_table}` will throw a column-not-found error, halting data refresh for affected EDL and ODS tables.{agg_note}{cast_note}

Recommended actions:
1. Identify ETL jobs referencing `{source_table}.{source_column}` and update SELECT statements
2. Coordinate with BI teams — dashboards consuming affected ODS columns will show stale or null data
3. If renaming the column, add a compatibility view before deprecating the original
4. Run data quality checks on downstream ODS tables post-change""",

        "type_change": f"""SEVERITY: {severity}

Changing the data type of `{source_column}` in `{source_table}` will affect {n_cols} downstream column(s) across {n_tables} table(s): {tbl_list or 'none'}.{cast_note}

Widening changes (e.g. INT to BIGINT) are usually safe. Narrowing or incompatible type changes will cause runtime cast errors in transformation jobs.{agg_note}

Recommended actions:
1. Review all CAST operations referencing this column downstream
2. Check ODS consumers for implicit type assumptions in application code
3. Test transformation scripts in a lower environment first
4. Monitor for silent truncation if the new type has lower precision""",

        "null_values": f"""SEVERITY: {severity}

Unexpected NULL values in `{source_column}` of `{source_table}` will propagate to {n_cols} downstream column(s) across {n_tables} table(s): {tbl_list or 'none'}.{coal_note}

Non-null-safe joins and aggregations may silently drop rows or skew metrics.{agg_note}

Recommended actions:
1. Investigate NULL source at EDW ingestion layer — likely an upstream feed issue
2. Add a NOT NULL data quality check on this column as a pipeline gate
3. Alert ODS consumers — aggregate totals will be understated until resolved
4. Review join conditions that use this column; NULL joins will silently drop rows""",

        "data_delay": f"""SEVERITY: {severity}

A data load delay on `{source_table}` will cascade to {n_tables} dependent table(s): {tbl_list or 'none'}.

Downstream pipelines with SLA dependencies will miss their refresh windows, causing stale data in {n_cols} columns across EDL and ODS layers.

Recommended actions:
1. Pause downstream pipeline triggers dependent on `{source_table}` until the feed recovers
2. Notify BI consumers — reports will show data as of the last successful load
3. Check if ODS tables have compensating carry-forward logic that could mask the delay
4. Trigger a full reconciliation run once the source recovers"""
    }
    return templates.get(change_type, f"Impact detected on {n_tables} table(s) and {n_cols} column(s).")

# ─── INFER SOURCE TABLES ───────────────────────────────────────────────────────
def infer_and_register_source_tables():
    """
    After all scripts are parsed, scan lineage_graph to find tables that are
    referenced as sources but have no metadata_store entry (i.e. EDW tables
    we have no CREATE script for). Build their column list from what downstream
    scripts reference and register them so they appear in the UI.
    """
    # Collect columns referenced from each unregistered source table
    inferred = {}  # source_table -> set of column names
    for tbl, info in lineage_graph.items():
        for col_data in info["columns"].values():
            for src in col_data.get("sources", []):
                st = src.get("source_table")
                sc = src.get("column")
                if st and sc and st not in metadata_store:
                    if st not in inferred:
                        inferred[st] = set()
                    inferred[st].add(sc)

    for src_table, cols in inferred.items():
        if src_table.startswith("EDW."):
            layer = "EDW"
        else:
            layer = "UNKNOWN"

        col_list = [{"name": c, "transform": "DIRECT", "source_columns": []} for c in sorted(cols)]

        metadata_store[src_table] = {
            "table": src_table,
            "layer": layer,
            "source_tables": [],   # EDW tables have no tracked upstream in this PoC
            "columns": col_list,
            "sql": "-- Source EDW table (inferred from downstream scripts)",
            "filename": "inferred"
        }
        # Also register in lineage_graph so BFS works both ways
        if src_table not in lineage_graph:
            lineage_graph[src_table] = {"source_tables": [], "columns": {}}

    print(f"Inferred and registered {len(inferred)} EDW source table(s): {list(inferred.keys())}")


# ─── STARTUP ───────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def load_samples():
    for filename, sql in SAMPLE_SCRIPTS.items():
        parsed = resolve_aliases(parse_sql(sql, filename), sql)
        store_parsed(parsed)
    infer_and_register_source_tables()
    print(f"Total tables in store: {list(metadata_store.keys())}")

# ─── ENDPOINTS ─────────────────────────────────────────────────────────────────
@app.get("/api/tables")
def get_tables():
    return {"tables": [
        {"name": t, "layer": m["layer"], "source_tables": m["source_tables"],
         "column_count": len(m["columns"]), "columns": [c["name"] for c in m["columns"]],
         "filename": m.get("filename", "")}
        for t, m in metadata_store.items()
    ]}

@app.get("/api/table/{table_name:path}")
def get_table_detail(table_name: str):
    key = table_name.upper()
    if key not in metadata_store:
        raise HTTPException(404, f"Table {key} not found")
    return metadata_store[key]

@app.get("/api/lineage")
def get_lineage():
    nodes, edges, seen = [], [], set()
    COLORS = {"EDW": "#378ADD", "EDL": "#1D9E75", "ODS": "#7F77DD", "UNKNOWN": "#888780"}
    for tbl, info in metadata_store.items():
        if tbl not in seen:
            nodes.append({"id": tbl, "label": tbl.split(".")[-1], "full_name": tbl,
                          "layer": info["layer"], "color": COLORS[info["layer"]],
                          "column_count": len(info["columns"])}); seen.add(tbl)
    for tbl, info in lineage_graph.items():
        for src in info.get("source_tables", []):
            if src not in seen:
                layer = "EDW" if src.startswith("EDW.") else "UNKNOWN"
                nodes.append({"id": src, "label": src.split(".")[-1], "full_name": src,
                              "layer": layer, "color": COLORS.get(layer, "#888780"), "column_count": 0})
                seen.add(src)
            edges.append({"source": src, "target": tbl, "id": f"{src}->{tbl}"})
    return {"nodes": nodes, "edges": edges}

class ImpactRequest(BaseModel):
    source_table: str
    source_column: str
    change_type: str

@app.post("/api/impact")
def analyze_impact(req: ImpactRequest):
    st, sc = req.source_table.upper(), req.source_column.upper()
    downstream = find_downstream_tables(st)
    aff_cols   = find_affected_columns(st, sc)
    severity   = "HIGH" if len(downstream) >= 3 else "MEDIUM" if downstream else "LOW"
    return {
        "source_table": st, "source_column": sc, "change_type": req.change_type,
        "severity": severity, "downstream_tables": downstream,
        "affected_columns": aff_cols,
        "ai_explanation": mock_ai_explanation(req.change_type, st, sc, downstream, aff_cols),
        "summary": {"tables_affected": len(downstream), "columns_affected": len(aff_cols)}
    }

class NLQueryRequest(BaseModel):
    query: str

@app.post("/api/nlquery")
def nl_query(req: NLQueryRequest):
    q = req.query.lower()
    matched_table = next((t for t in metadata_store if t.split(".")[-1].lower() in q or t.lower() in q), None)
    matched_col = None
    if matched_table:
        matched_col = next((c["name"] for c in metadata_store[matched_table]["columns"] if c["name"].lower() in q), None)

    if any(w in q for w in ["break", "drop", "remove", "delete", "impact", "affect"]):
        if matched_table and matched_col:
            downstream = find_downstream_tables(matched_table)
            aff_cols   = find_affected_columns(matched_table, matched_col)
            answer = f"Dropping `{matched_col}` from `{matched_table}` affects **{len(aff_cols)} downstream columns** across **{len(downstream)} tables**:\n\n"
            for ac in aff_cols[:6]:
                answer += f"- `{ac['table']}.{ac['column']}` ({ac['transform']})\n"
            if not aff_cols:
                answer = f"No direct column-level impact found for `{matched_col}` in `{matched_table}`. Downstream tables: {', '.join(downstream) or 'none'}."
        elif matched_table:
            downstream = find_downstream_tables(matched_table)
            answer = f"`{matched_table}` affects **{len(downstream)} downstream table(s)**:\n\n" + "\n".join([f"- {t}" for t in downstream]) or "No downstream dependents found."
        else:
            answer = "Please mention a specific table name (e.g. `EDW.CUSTOMER`) in your question."
    elif any(w in q for w in ["depend", "source", "comes from", "upstream", "built from"]):
        if matched_table:
            srcs = metadata_store[matched_table].get("source_tables", [])
            answer = f"`{matched_table}` is built from:\n\n" + "\n".join([f"- `{s}`" for s in srcs])
        else:
            answer = "Please specify a table name to look up its source dependencies."
    elif any(w in q for w in ["column", "fields", "schema", "what columns"]):
        if matched_table:
            cols = [c["name"] for c in metadata_store[matched_table]["columns"]]
            answer = f"`{matched_table}` has **{len(cols)} columns**:\n\n" + ", ".join([f"`{c}`" for c in cols])
        else:
            all_tbls = "\n".join([f"- `{t}` ({metadata_store[t]['layer']}, {len(metadata_store[t]['columns'])} cols)" for t in metadata_store])
            answer = f"All registered tables:\n\n{all_tbls}"
    elif any(w in q for w in ["critical", "risk", "important", "most impact"]):
        ranked = sorted(metadata_store.keys(), key=lambda t: len(find_downstream_tables(t)), reverse=True)
        answer = "**Most critical tables by downstream impact:**\n\n"
        for t in ranked[:5]:
            n = len(find_downstream_tables(t))
            answer += f"- `{t}` → {n} downstream table(s)\n"
    elif any(w in q for w in ["table", "how many", "list", "all tables"]):
        all_tbls = "\n".join([f"- `{t}` ({metadata_store[t]['layer']})" for t in metadata_store])
        answer = f"Tracking **{len(metadata_store)} tables**:\n\n{all_tbls}"
    else:
        answer = ("I can answer questions like:\n\n"
                  "- *What breaks if I drop EDW.CUSTOMER.risk_score?*\n"
                  "- *What does EDL.TRANSACTION_SUMMARY depend on?*\n"
                  "- *What columns does ODS.RISK_EXPOSURE have?*\n"
                  "- *Which tables are most critical?*\n\n"
                  f"Currently tracking **{len(metadata_store)} tables**.")
    return {"query": req.query, "matched_table": matched_table, "matched_column": matched_col, "answer": answer}

@app.post("/api/upload")
async def upload_sql(file: UploadFile = File(...)):
    if not file.filename.endswith(".sql"):
        raise HTTPException(400, "Only .sql files accepted")
    sql = (await file.read()).decode("utf-8")
    parsed = resolve_aliases(parse_sql(sql, file.filename), sql)
    store_parsed(parsed)
    infer_and_register_source_tables()
    return {"message": f"Parsed and stored: {parsed.get('target_table', 'unknown')}",
            "table": parsed.get("target_table"), "layer": parsed.get("layer"),
            "columns_found": len(parsed.get("columns", [])),
            "source_tables": parsed.get("source_tables", []),
            "parse_error": parsed.get("parse_error")}

@app.post("/api/samples/{filename}")
def load_sample(filename: str):
    if filename not in SAMPLE_SCRIPTS:
        raise HTTPException(404, "Sample not found")
    sql = SAMPLE_SCRIPTS[filename]
    parsed = resolve_aliases(parse_sql(sql, filename), sql)
    store_parsed(parsed)
    infer_and_register_source_tables()
    return {"message": f"Loaded sample: {parsed.get('target_table')}",
            "table": parsed.get("target_table"), "layer": parsed.get("layer"),
            "columns_found": len(parsed.get("columns", []))}

@app.get("/api/samples")
def get_samples():
    return {"samples": list(SAMPLE_SCRIPTS.keys())}

@app.get("/")
def root():
    return {"status": "ok", "tables_loaded": len(metadata_store)}
