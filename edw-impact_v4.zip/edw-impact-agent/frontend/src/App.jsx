import { useState, useEffect, useRef, useCallback } from "react";
import * as d3 from "d3";

const API = "http://localhost:8000";

const LAYER_COLOR = {
  EDW: { bg: "#dbeafe", text: "#1d4ed8", border: "#3b82f6" },
  EDL: { bg: "#d1fae5", text: "#065f46", border: "#10b981" },
  ODS: { bg: "#ede9fe", text: "#4c1d95", border: "#8b5cf6" },
  UNKNOWN: { bg: "#f3f4f6", text: "#374151", border: "#9ca3af" },
};

const SEVERITY_COLOR = {
  HIGH:   { bg: "#fee2e2", text: "#991b1b", border: "#ef4444", dot: "#dc2626" },
  MEDIUM: { bg: "#fef3c7", text: "#92400e", border: "#f59e0b", dot: "#d97706" },
  LOW:    { bg: "#d1fae5", text: "#065f46", border: "#10b981", dot: "#059669" },
};

// ─── COMPONENTS ───────────────────────────────────────────────────────────────

function Badge({ layer }) {
  const c = LAYER_COLOR[layer] || LAYER_COLOR.UNKNOWN;
  return (
    <span style={{
      padding: "2px 8px", borderRadius: 12, fontSize: 11, fontWeight: 600,
      background: c.bg, color: c.text, border: `1px solid ${c.border}`
    }}>{layer}</span>
  );
}

function SeverityBadge({ severity }) {
  const c = SEVERITY_COLOR[severity] || SEVERITY_COLOR.LOW;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "3px 10px", borderRadius: 12, fontSize: 12, fontWeight: 700,
      background: c.bg, color: c.text, border: `1px solid ${c.border}`
    }}>
      <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.dot, display: "inline-block" }} />
      {severity}
    </span>
  );
}

function Card({ children, style = {} }) {
  return (
    <div style={{
      background: "#fff", borderRadius: 12, border: "1px solid #e5e7eb",
      boxShadow: "0 1px 4px rgba(0,0,0,0.06)", padding: "20px 24px",
      ...style
    }}>{children}</div>
  );
}

function Spinner() {
  return (
    <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
      <div style={{
        width: 36, height: 36, borderRadius: "50%",
        border: "3px solid #e5e7eb", borderTopColor: "#6366f1", animation: "spin 0.7s linear infinite"
      }} />
    </div>
  );
}

function MarkdownText({ text }) {
  if (!text) return null;
  const lines = text.split("\n");
  return (
    <div style={{ lineHeight: 1.7, fontSize: 14 }}>
      {lines.map((line, i) => {
        if (line.startsWith("SEVERITY:") || line.includes("**")) {
          const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g);
          return (
            <p key={i} style={{ margin: "6px 0" }}>
              {parts.map((p, j) => {
                if (p.startsWith("**") && p.endsWith("**")) return <strong key={j}>{p.slice(2, -2)}</strong>;
                if (p.startsWith("`") && p.endsWith("`")) return <code key={j} style={{ background: "#f3f4f6", padding: "1px 5px", borderRadius: 4, fontSize: 12 }}>{p.slice(1, -1)}</code>;
                return p;
              })}
            </p>
          );
        }
        if (line.match(/^\d+\./)) {
          const parts = line.split(/(`.*?`)/g);
          return (
            <p key={i} style={{ margin: "4px 0 4px 16px" }}>
              {parts.map((p, j) => p.startsWith("`") && p.endsWith("`")
                ? <code key={j} style={{ background: "#f3f4f6", padding: "1px 5px", borderRadius: 4, fontSize: 12 }}>{p.slice(1, -1)}</code>
                : p)}
            </p>
          );
        }
        if (line.trim() === "") return <br key={i} />;
        const parts = line.split(/(`.*?`)/g);
        return (
          <p key={i} style={{ margin: "4px 0" }}>
            {parts.map((p, j) => p.startsWith("`") && p.endsWith("`")
              ? <code key={j} style={{ background: "#f3f4f6", padding: "1px 5px", borderRadius: 4, fontSize: 12 }}>{p.slice(1, -1)}</code>
              : p)}
          </p>
        );
      })}
    </div>
  );
}

// ─── TAB 1: SQL Upload & Metadata ─────────────────────────────────────────────
function TabUpload({ onRefresh }) {
  const [samples, setSamples] = useState([]);
  const [tables, setTables] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [loadingIdx, setLoadingIdx] = useState(null);
  const [msg, setMsg] = useState(null);
  const [selected, setSelected] = useState(null);

  const load = useCallback(async () => {
    const [s, t] = await Promise.all([
      fetch(`${API}/api/samples`).then(r => r.json()),
      fetch(`${API}/api/tables`).then(r => r.json()),
    ]);
    setSamples(s.samples || []);
    setTables(t.tables || []);
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadSample = async (name, idx) => {
    setLoadingIdx(idx);
    try {
      const r = await fetch(`${API}/api/samples/${name}`, { method: "POST" });
      const d = await r.json();
      setMsg({ type: "success", text: `✓ Loaded ${d.table} (${d.columns_found} columns)` });
      await load(); onRefresh();
    } catch { setMsg({ type: "error", text: "Failed to load sample." }); }
    setLoadingIdx(null);
  };

  const uploadFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);
    try {
      const r = await fetch(`${API}/api/upload`, { method: "POST", body: fd });
      const d = await r.json();
      if (d.parse_error) setMsg({ type: "warning", text: `Partial parse: ${d.parse_error}` });
      else setMsg({ type: "success", text: `✓ Uploaded ${d.table} (${d.columns_found} columns found)` });
      await load(); onRefresh();
    } catch { setMsg({ type: "error", text: "Upload failed." }); }
    setUploading(false);
    e.target.value = "";
  };

  const fetchDetail = async (tbl) => {
    const d = await fetch(`${API}/api/table/${tbl}`).then(r => r.json());
    setSelected(d);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "340px 1fr", gap: 20 }}>
      {/* Left panel */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <Card>
          <h3 style={{ margin: "0 0 14px", fontSize: 15, color: "#111" }}>Sample Scripts</h3>
          <p style={{ margin: "0 0 12px", fontSize: 13, color: "#6b7280" }}>
            Pre-loaded EDW→EDL→ODS pipeline scripts for demo
          </p>
          {samples.map((s, i) => (
            <div key={s} style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "10px 12px", marginBottom: 8, borderRadius: 8,
              background: "#f9fafb", border: "1px solid #e5e7eb"
            }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500, color: "#374151" }}>{s}</div>
                <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>
                  {s.startsWith("edl") ? "EDL layer" : "ODS layer"}
                </div>
              </div>
              <button onClick={() => loadSample(s, i)}
                disabled={loadingIdx === i}
                style={{
                  padding: "5px 12px", borderRadius: 6, border: "none",
                  background: loadingIdx === i ? "#e5e7eb" : "#6366f1",
                  color: loadingIdx === i ? "#9ca3af" : "#fff",
                  fontSize: 12, cursor: loadingIdx === i ? "not-allowed" : "pointer", fontWeight: 500
                }}>
                {loadingIdx === i ? "Loading…" : "Load"}
              </button>
            </div>
          ))}
        </Card>

        <Card>
          <h3 style={{ margin: "0 0 12px", fontSize: 15, color: "#111" }}>Upload Your SQL</h3>
          <label style={{
            display: "flex", flexDirection: "column", alignItems: "center",
            padding: "20px", border: "2px dashed #d1d5db", borderRadius: 8,
            cursor: "pointer", background: "#fafafa", color: "#6b7280", fontSize: 13
          }}>
            <span style={{ fontSize: 28 }}>📄</span>
            <span style={{ marginTop: 8, fontWeight: 500 }}>Click to upload .sql file</span>
            <span style={{ fontSize: 11, marginTop: 4 }}>CREATE TABLE AS SELECT supported</span>
            <input type="file" accept=".sql" onChange={uploadFile} style={{ display: "none" }} />
          </label>
          {uploading && <div style={{ textAlign: "center", marginTop: 10, color: "#6b7280", fontSize: 13 }}>Parsing…</div>}
        </Card>

        {msg && (
          <div style={{
            padding: "10px 14px", borderRadius: 8, fontSize: 13,
            background: msg.type === "success" ? "#d1fae5" : msg.type === "warning" ? "#fef3c7" : "#fee2e2",
            color: msg.type === "success" ? "#065f46" : msg.type === "warning" ? "#92400e" : "#991b1b",
            border: `1px solid ${msg.type === "success" ? "#a7f3d0" : msg.type === "warning" ? "#fde68a" : "#fecaca"}`
          }}>
            {msg.text}
            <button onClick={() => setMsg(null)} style={{ float: "right", background: "none", border: "none", cursor: "pointer", color: "inherit" }}>✕</button>
          </div>
        )}
      </div>

      {/* Right panel: table list + detail */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <Card>
          <h3 style={{ margin: "0 0 14px", fontSize: 15, color: "#111" }}>
            Metadata Store
            <span style={{ fontWeight: 400, fontSize: 13, color: "#6b7280", marginLeft: 8 }}>
              {tables.length} tables registered
            </span>
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {tables.map(t => (
              <div key={t.name}
                onClick={() => fetchDetail(t.name)}
                style={{
                  padding: "12px 14px", borderRadius: 8, cursor: "pointer",
                  border: `1px solid ${selected?.table === t.name ? "#6366f1" : "#e5e7eb"}`,
                  background: selected?.table === t.name ? "#f0f0ff" : "#f9fafb",
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  transition: "all 0.15s"
                }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13, color: "#111" }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: "#9ca3af", marginTop: 3 }}>
                    Sources: {t.source_tables.join(", ") || "—"}
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ fontSize: 12, color: "#6b7280" }}>{t.column_count} cols</span>
                  <Badge layer={t.layer} />
                </div>
              </div>
            ))}
            {tables.length === 0 && (
              <div style={{ textAlign: "center", color: "#9ca3af", padding: 30, fontSize: 13 }}>
                No tables registered yet. Load a sample or upload a SQL file.
              </div>
            )}
          </div>
        </Card>

        {selected && (
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div>
                <h3 style={{ margin: 0, fontSize: 15, color: "#111" }}>{selected.table}</h3>
                <div style={{ fontSize: 12, color: "#6b7280", marginTop: 4 }}>
                  From: {selected.filename}
                </div>
              </div>
              <Badge layer={selected.layer} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
              {selected.columns.map(c => (
                <div key={c.name} style={{
                  padding: "8px 10px", borderRadius: 6, background: "#f9fafb", border: "1px solid #e5e7eb"
                }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "#374151" }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>{c.transform}</div>
                </div>
              ))}
            </div>
            <details>
              <summary style={{ fontSize: 12, color: "#6b7280", cursor: "pointer" }}>Show SQL</summary>
              <pre style={{
                marginTop: 8, padding: 12, background: "#1e1e2e", color: "#cdd6f4",
                borderRadius: 8, fontSize: 11, overflow: "auto", maxHeight: 200
              }}>{selected.sql}</pre>
            </details>
          </Card>
        )}
      </div>
    </div>
  );
}

// ─── TAB 2: Lineage Graph ──────────────────────────────────────────────────────
function TabLineage() {
  const [lineage, setLineage] = useState(null);
  const [tooltip, setTooltip] = useState(null);
  const [filter, setFilter] = useState(null); // highlighted table id
  const [tables, setTables] = useState([]);

  const fetchAll = useCallback(() => {
    Promise.all([
      fetch(`${API}/api/lineage`).then(r => r.json()),
      fetch(`${API}/api/tables`).then(r => r.json()),
    ]).then(([lin, tbl]) => {
      setLineage(lin);
      setTables(tbl.tables || []);
    });
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // Draw whenever lineage or filter changes
  useEffect(() => {
    if (!lineage) return;
    const t = setTimeout(() => drawGraph(lineage, filter), 60);
    return () => clearTimeout(t);
  }, [lineage, filter]);

  function drawGraph(data, highlightId) {
    const container = document.getElementById("lineage-svg-container");
    if (!container) return;
    const W = container.clientWidth || 860;
    if (W < 50) return;

    const { nodes, edges } = data;
    if (!nodes || !nodes.length) return;

    const H = Math.max(480, nodes.length * 72);

    // Find connected node ids for highlight
    const connected = new Set();
    if (highlightId) {
      connected.add(highlightId);
      edges.forEach(e => {
        if (e.source === highlightId) connected.add(e.target);
        if (e.target === highlightId) connected.add(e.source);
      });
    }

    // Clear and rebuild
    const existing = document.getElementById("lineage-svg");
    if (existing) existing.remove();
    const svgEl = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svgEl.setAttribute("id", "lineage-svg");
    svgEl.setAttribute("width", "100%");
    svgEl.setAttribute("height", H);
    svgEl.setAttribute("viewBox", `0 0 ${W} ${H}`);
    container.appendChild(svgEl);

    const svg = d3.select(svgEl);

    // Arrow marker
    const defs = svg.append("defs");
    defs.append("marker").attr("id","arrowG").attr("viewBox","0 -5 10 10")
      .attr("refX",20).attr("refY",0).attr("markerWidth",6).attr("markerHeight",6).attr("orient","auto")
      .append("path").attr("d","M0,-5L10,0L0,5").attr("fill","#94a3b8");
    defs.append("marker").attr("id","arrowH").attr("viewBox","0 -5 10 10")
      .attr("refX",20).attr("refY",0).attr("markerWidth",6).attr("markerHeight",6).attr("orient","auto")
      .append("path").attr("d","M0,-5L10,0L0,5").attr("fill","#6366f1");

    // Layer bands
    const bands = [
      ["EDW", 0,        W*0.32, "#3b82f6"],
      ["EDL", W*0.33,   W*0.32, "#10b981"],
      ["ODS", W*0.66,   W*0.34, "#8b5cf6"],
    ];
    bands.forEach(([label, lx, lw, color]) => {
      svg.append("rect").attr("x",lx).attr("y",0).attr("width",lw).attr("height",H)
        .attr("fill",color).attr("opacity",0.035);
      svg.append("text").attr("x",lx+lw/2).attr("y",20)
        .attr("text-anchor","middle").attr("font-size",11).attr("font-weight",700)
        .attr("fill",color).attr("opacity",0.7).attr("font-family","system-ui,sans-serif").text(label);
    });

    // Position nodes by layer
    const layerGroups = { EDW:[], EDL:[], ODS:[], UNKNOWN:[] };
    nodes.forEach(n => (layerGroups[n.layer] || layerGroups.UNKNOWN).push(n));
    const LAYER_X = { EDW: W*0.155, EDL: W*0.495, ODS: W*0.83 };
    const positioned = new Map();
    Object.entries(layerGroups).forEach(([layer, grp]) => {
      if (!grp.length) return;
      const x = LAYER_X[layer] || W*0.5;
      const slotH = (H - 60) / grp.length;
      grp.forEach((n,i) => {
        positioned.set(n.id, { ...n, x, y: 40 + i*slotH + slotH/2 });
      });
    });

    // Edges
    edges.forEach(e => {
      const src = positioned.get(e.source), tgt = positioned.get(e.target);
      if (!src || !tgt) return;
      const isHighlighted = highlightId && (e.source === highlightId || e.target === highlightId);
      const dimmed = highlightId && !isHighlighted;
      const mx = (src.x + tgt.x) / 2;
      svg.append("path")
        .attr("d", `M ${src.x+70} ${src.y} C ${mx} ${src.y}, ${mx} ${tgt.y}, ${tgt.x-70} ${tgt.y}`)
        .attr("fill","none")
        .attr("stroke", isHighlighted ? "#6366f1" : "#cbd5e1")
        .attr("stroke-width", isHighlighted ? 2.5 : 1.5)
        .attr("opacity", dimmed ? 0.15 : 1)
        .attr("marker-end", `url(${isHighlighted ? "#arrowH" : "#arrowG"})`);
    });

    // Nodes
    const WN=140, HN=46;
    positioned.forEach(n => {
      const isHighlighted = !highlightId || connected.has(n.id);
      const isSelected = n.id === highlightId;
      const lc = LAYER_COLOR[n.layer] || LAYER_COLOR.UNKNOWN;

      const g = svg.append("g").attr("cursor","pointer")
        .on("click", () => {
          // dispatch custom event to React
          container.dispatchEvent(new CustomEvent("nodeclick", { detail: n.id, bubbles:true }));
        })
        .on("mouseenter", (evt) => {
          const tip = document.getElementById("lineage-tooltip");
          if (tip) {
            tip.style.display = "block";
            tip.style.left = (evt.clientX+14)+"px";
            tip.style.top  = (evt.clientY-36)+"px";
            tip.innerHTML = `<div style="font-weight:700;margin-bottom:4px">${n.full_name}</div>
              <div style="color:#94a3b8">Layer: <span style="color:#f1f5f9">${n.layer}</span></div>
              <div style="color:#94a3b8">Columns: <span style="color:#f1f5f9">${n.column_count}</span></div>
              <div style="color:#94a3b8;margin-top:4px;font-size:11px">Click to highlight lineage</div>`;
          }
        })
        .on("mouseleave", () => {
          const tip = document.getElementById("lineage-tooltip");
          if (tip) tip.style.display = "none";
        });

      g.append("rect")
        .attr("x", n.x-WN/2).attr("y", n.y-HN/2)
        .attr("width", WN).attr("height", HN).attr("rx", 8)
        .attr("fill", isSelected ? lc.border : lc.bg)
        .attr("stroke", isSelected ? lc.text : lc.border)
        .attr("stroke-width", isSelected ? 2.5 : 1.5)
        .attr("opacity", isHighlighted ? 1 : 0.2);

      g.append("text")
        .attr("x", n.x).attr("y", n.y - (n.column_count>0 ? 7 : 0))
        .attr("text-anchor","middle").attr("dominant-baseline","central")
        .attr("font-size",12).attr("font-weight",600)
        .attr("font-family","system-ui,sans-serif")
        .attr("fill", isSelected ? "#fff" : (isHighlighted ? lc.text : "#9ca3af"))
        .text(n.label.length>15 ? n.label.slice(0,14)+"…" : n.label);

      if (n.column_count > 0) {
        g.append("text")
          .attr("x", n.x).attr("y", n.y+12)
          .attr("text-anchor","middle").attr("dominant-baseline","central")
          .attr("font-size",10).attr("font-family","system-ui,sans-serif")
          .attr("fill", isSelected ? "#e0e7ff" : (isHighlighted ? "#9ca3af" : "#d1d5db"))
          .text(`${n.column_count} cols`);
      }
    });
  }

  // Listen for node clicks from D3
  useEffect(() => {
    const el = document.getElementById("lineage-svg-container");
    if (!el) return;
    const handler = (e) => {
      setFilter(f => f === e.detail ? null : e.detail);
    };
    el.addEventListener("nodeclick", handler);
    return () => el.removeEventListener("nodeclick", handler);
  }, [lineage]);

  const nodeCount = lineage?.nodes?.length || 0;
  const edgeCount = lineage?.edges?.length || 0;
  const selectedTable = filter ? tables.find(t => t.name === filter) : null;

  return (
    <div>
      <Card style={{ padding:"16px 20px", marginBottom:16 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
          <div style={{ display:"flex", alignItems:"center", gap:16 }}>
            <h3 style={{ margin:0, fontSize:15, color:"#111" }}>Data Lineage Graph</h3>
            <span style={{ fontSize:12, color:"#9ca3af" }}>{nodeCount} nodes · {edgeCount} edges</span>
            {filter && (
              <span style={{
                padding:"3px 10px", borderRadius:12, background:"#ede9fe",
                color:"#4c1d95", fontSize:12, fontWeight:600, border:"1px solid #c4b5fd"
              }}>
                Showing lineage of: {filter.split(".")[1]}
                <button onClick={() => setFilter(null)}
                  style={{ marginLeft:6, background:"none", border:"none", cursor:"pointer", color:"#7c3aed", fontWeight:700 }}>✕</button>
              </span>
            )}
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            {Object.entries(LAYER_COLOR).filter(([k]) => k!=="UNKNOWN").map(([layer,c]) => (
              <span key={layer} style={{ display:"flex", alignItems:"center", gap:5, fontSize:12, color:"#6b7280" }}>
                <span style={{ width:12, height:12, borderRadius:3, background:c.bg, border:`1.5px solid ${c.border}`, display:"inline-block" }}/>
                {layer}
              </span>
            ))}
            <button onClick={fetchAll} style={{
              padding:"5px 12px", borderRadius:6, border:"1px solid #e5e7eb",
              background:"#f9fafb", fontSize:12, cursor:"pointer", color:"#374151"
            }}>↻ Refresh</button>
          </div>
        </div>

        <div style={{ display:"flex", gap:16 }}>
          {/* Table list sidebar */}
          <div style={{ width:200, flexShrink:0 }}>
            <div style={{ fontSize:11, fontWeight:600, color:"#9ca3af", marginBottom:8, textTransform:"uppercase", letterSpacing:"0.05em" }}>
              Click to highlight
            </div>
            {tables.map(t => (
              <div key={t.name} onClick={() => setFilter(f => f===t.name ? null : t.name)}
                style={{
                  padding:"8px 10px", marginBottom:6, borderRadius:7, cursor:"pointer",
                  background: filter===t.name ? (LAYER_COLOR[t.layer]?.bg||"#f3f4f6") : "#f9fafb",
                  border:`1.5px solid ${filter===t.name ? (LAYER_COLOR[t.layer]?.border||"#9ca3af") : "#e5e7eb"}`,
                  transition:"all 0.12s"
                }}>
                <div style={{ fontSize:11, fontWeight:600, color: LAYER_COLOR[t.layer]?.text||"#374151" }}>
                  {t.name.split(".")[1]}
                </div>
                <div style={{ fontSize:10, color:"#9ca3af", marginTop:2 }}>{t.layer} · {t.column_count} cols</div>
              </div>
            ))}
            {tables.length === 0 && (
              <div style={{ fontSize:12, color:"#9ca3af", padding:"8px 0" }}>No tables yet</div>
            )}
          </div>

          {/* Graph area */}
          <div id="lineage-svg-container" style={{ flex:1, minHeight:400, background:"#fafafa", borderRadius:8, position:"relative", overflow:"hidden" }}>
            {nodeCount === 0 && (
              <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:400, color:"#9ca3af", fontSize:13 }}>
                Load SQL scripts on the Metadata tab first
              </div>
            )}
          </div>
        </div>

        {filter && selectedTable && (
          <div style={{ marginTop:14, padding:"12px 14px", borderRadius:8, background:"#f5f3ff", border:"1px solid #ddd6fe" }}>
            <div style={{ fontSize:12, fontWeight:600, color:"#4c1d95", marginBottom:6 }}>
              {filter} — direct connections
            </div>
            <div style={{ fontSize:12, color:"#6b7280" }}>
              <span style={{ marginRight:16 }}>⬆ Sources: <strong style={{color:"#111"}}>{selectedTable.source_tables?.join(", ")||"none"}</strong></span>
              <span>⬇ Used by: <strong style={{color:"#111"}}>
                {lineage?.edges?.filter(e => e.source===filter).map(e=>e.target).join(", ")||"none"}
              </strong></span>
            </div>
          </div>
        )}
      </Card>

      {/* Tooltip — rendered outside SVG, positioned via JS */}
      <div id="lineage-tooltip" style={{
        display:"none", position:"fixed", background:"#1e293b", color:"#f1f5f9",
        padding:"10px 14px", borderRadius:8, fontSize:12, pointerEvents:"none",
        zIndex:9999, boxShadow:"0 4px 16px rgba(0,0,0,0.2)"
      }}/>
    </div>
  );
}

// ─── TAB 3: Impact Simulator ───────────────────────────────────────────────────
function TabImpact() {
  const [tables, setTables] = useState([]);
  const [form, setForm] = useState({ source_table: "", source_column: "", change_type: "drop_column" });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const cols = tables.find(t => t.name === form.source_table)?.columns || [];

  useEffect(() => {
    fetch(`${API}/api/tables`).then(r => r.json()).then(d => setTables(d.tables || []));
  }, []);

  const analyze = async () => {
    if (!form.source_table || !form.source_column) return;
    setLoading(true); setResult(null);
    try {
      const r = await fetch(`${API}/api/impact`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      setResult(await r.json());
    } catch {}
    setLoading(false);
  };

  const SEL_STYLE = {
    width: "100%", padding: "9px 12px", borderRadius: 8,
    border: "1px solid #d1d5db", fontSize: 13, color: "#111",
    background: "#fff", outline: "none"
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20 }}>
      <Card>
        <h3 style={{ margin: "0 0 16px", fontSize: 15, color: "#111" }}>Simulate EDW Change</h3>

        <label style={{ display: "block", marginBottom: 14 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: "#374151", display: "block", marginBottom: 6 }}>Source Table</span>
          <select style={SEL_STYLE} value={form.source_table}
            onChange={e => setForm(f => ({ ...f, source_table: e.target.value, source_column: "" }))}>
            <option value="">Select a table…</option>
            {tables.map(t => <option key={t.name} value={t.name}>{t.name}</option>)}
          </select>
        </label>

        <label style={{ display: "block", marginBottom: 14 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: "#374151", display: "block", marginBottom: 6 }}>Affected Column</span>
          <select style={SEL_STYLE} value={form.source_column}
            onChange={e => setForm(f => ({ ...f, source_column: e.target.value }))}
            disabled={!form.source_table}>
            <option value="">Select a column…</option>
            {cols.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>

        <label style={{ display: "block", marginBottom: 20 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: "#374151", display: "block", marginBottom: 6 }}>Change Type</span>
          <select style={SEL_STYLE} value={form.change_type}
            onChange={e => setForm(f => ({ ...f, change_type: e.target.value }))}>
            <option value="drop_column">Drop Column</option>
            <option value="type_change">Type Change</option>
            <option value="null_values">Null Values Introduced</option>
            <option value="data_delay">Data Load Delay</option>
          </select>
        </label>

        <button onClick={analyze}
          disabled={!form.source_table || !form.source_column || loading}
          style={{
            width: "100%", padding: "11px", borderRadius: 8, border: "none",
            background: (!form.source_table || !form.source_column || loading) ? "#e5e7eb" : "#6366f1",
            color: (!form.source_table || !form.source_column || loading) ? "#9ca3af" : "#fff",
            fontSize: 14, fontWeight: 600, cursor: (!form.source_table || !form.source_column || loading) ? "not-allowed" : "pointer"
          }}>
          {loading ? "Analyzing…" : "⚡ Run Impact Analysis"}
        </button>
      </Card>

      <div>
        {loading && <Card><Spinner /></Card>}
        {result && !loading && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Summary */}
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <h3 style={{ margin: 0, fontSize: 15, color: "#111" }}>Impact Summary</h3>
                <SeverityBadge severity={result.severity} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                {[
                  ["Tables Affected", result.summary.tables_affected, "#ef4444"],
                  ["Columns Affected", result.summary.columns_affected, "#f59e0b"],
                  ["Change Type", result.change_type.replace("_", " ").toUpperCase(), "#6366f1"]
                ].map(([label, val, color]) => (
                  <div key={label} style={{ padding: "14px 16px", borderRadius: 8, background: "#f9fafb", border: "1px solid #e5e7eb" }}>
                    <div style={{ fontSize: 24, fontWeight: 700, color }}>{val}</div>
                    <div style={{ fontSize: 12, color: "#9ca3af", marginTop: 4 }}>{label}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* AI Explanation */}
            <Card>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <span style={{ fontSize: 18 }}>🤖</span>
                <h3 style={{ margin: 0, fontSize: 15, color: "#111" }}>AI Impact Analysis</h3>
              </div>
              <div style={{ background: "#f8f9ff", borderRadius: 8, padding: "14px 16px", border: "1px solid #e0e7ff" }}>
                <MarkdownText text={result.ai_explanation} />
              </div>
            </Card>

            {/* Affected Columns */}
            {result.affected_columns.length > 0 && (
              <Card>
                <h3 style={{ margin: "0 0 14px", fontSize: 15, color: "#111" }}>
                  Affected Downstream Columns
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {result.affected_columns.map((c, i) => (
                    <div key={i} style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      padding: "10px 14px", borderRadius: 8, background: "#f9fafb", border: "1px solid #e5e7eb"
                    }}>
                      <div>
                        <code style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>
                          {c.table}.{c.column}
                        </code>
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 10, background: "#fef3c7", color: "#92400e", border: "1px solid #fde68a" }}>
                          {c.transform}
                        </span>
                        <Badge layer={c.layer} />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Downstream tables */}
            {result.downstream_tables.length > 0 && (
              <Card>
                <h3 style={{ margin: "0 0 14px", fontSize: 15, color: "#111" }}>Downstream Tables in Blast Radius</h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {result.downstream_tables.map(t => (
                    <span key={t} style={{
                      padding: "6px 12px", borderRadius: 20, background: "#fee2e2",
                      color: "#991b1b", fontSize: 12, fontWeight: 500, border: "1px solid #fecaca"
                    }}>⚠ {t}</span>
                  ))}
                </div>
              </Card>
            )}
          </div>
        )}
        {!result && !loading && (
          <Card style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 300 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>⚡</div>
            <h3 style={{ margin: "0 0 8px", color: "#374151" }}>Ready to Analyze</h3>
            <p style={{ color: "#9ca3af", fontSize: 14, textAlign: "center", margin: 0 }}>
              Select a table and column, choose a change type,<br />and run the impact analysis.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}

// ─── TAB 4: NL Q&A ────────────────────────────────────────────────────────────
function TabNLQA() {
  const [query, setQuery] = useState("");
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  const SUGGESTIONS = [
    "What breaks if I drop EDW.CUSTOMER.risk_score?",
    "What does EDL.TRANSACTION_SUMMARY depend on?",
    "What columns does ODS.RISK_EXPOSURE have?",
    "Which tables are most critical?",
    "What tables does EDW.ACCOUNT affect?",
  ];

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [history]);

  const ask = async (q) => {
    const question = q || query;
    if (!question.trim()) return;
    setHistory(h => [...h, { role: "user", text: question }]);
    setQuery(""); setLoading(true);
    try {
      const r = await fetch(`${API}/api/nlquery`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: question })
      });
      const d = await r.json();
      setHistory(h => [...h, { role: "agent", text: d.answer, meta: { table: d.matched_table, col: d.matched_column } }]);
    } catch {
      setHistory(h => [...h, { role: "agent", text: "Sorry, something went wrong." }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 20, height: "calc(100vh - 220px)", minHeight: 400 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <Card style={{ padding: "14px 16px" }}>
          <h4 style={{ margin: "0 0 10px", fontSize: 13, color: "#374151" }}>Suggested Questions</h4>
          {SUGGESTIONS.map((s, i) => (
            <button key={i} onClick={() => ask(s)}
              style={{
                width: "100%", textAlign: "left", padding: "8px 10px", marginBottom: 6,
                borderRadius: 6, border: "1px solid #e5e7eb", background: "#f9fafb",
                fontSize: 12, color: "#374151", cursor: "pointer", lineHeight: 1.4
              }}>
              {s}
            </button>
          ))}
        </Card>
        <Card style={{ padding: "14px 16px" }}>
          <h4 style={{ margin: "0 0 8px", fontSize: 13, color: "#374151" }}>Agent Capabilities</h4>
          {["Column-level impact tracing", "Source dependency lookup", "Schema inspection", "Criticality ranking"].map(cap => (
            <div key={cap} style={{ fontSize: 11, color: "#6b7280", marginBottom: 5, display: "flex", gap: 6 }}>
              <span>✓</span><span>{cap}</span>
            </div>
          ))}
        </Card>
      </div>

      <Card style={{ display: "flex", flexDirection: "column", padding: 0, overflow: "hidden" }}>
        {/* Chat window */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px", display: "flex", flexDirection: "column", gap: 16 }}>
          {history.length === 0 && (
            <div style={{ margin: "auto", textAlign: "center", color: "#9ca3af" }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🤖</div>
              <div style={{ fontWeight: 600, color: "#374151", marginBottom: 8 }}>EDW Impact Agent</div>
              <div style={{ fontSize: 13 }}>Ask me about lineage, impact, or schema across your data pipeline.</div>
            </div>
          )}
          {history.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
              {m.role === "agent" && (
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#6366f1", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, marginRight: 8, flexShrink: 0, marginTop: 2 }}>🤖</div>
              )}
              <div style={{
                maxWidth: "72%", padding: "12px 16px", borderRadius: m.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                background: m.role === "user" ? "#6366f1" : "#f3f4f6",
                color: m.role === "user" ? "#fff" : "#111",
                fontSize: 13, lineHeight: 1.6
              }}>
                {m.role === "user" ? m.text : <MarkdownText text={m.text} />}
                {m.meta?.table && (
                  <div style={{ marginTop: 8, fontSize: 11, opacity: 0.7 }}>
                    Resolved: {m.meta.table}{m.meta.col ? `.${m.meta.col}` : ""}
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", gap: 8 }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#6366f1", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>🤖</div>
              <div style={{ padding: "12px 16px", borderRadius: "18px 18px 18px 4px", background: "#f3f4f6" }}>
                <div style={{ display: "flex", gap: 4 }}>
                  {[0, 1, 2].map(i => (
                    <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#6366f1", animation: `bounce 1s ${i * 0.2}s infinite` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Input bar */}
        <div style={{ padding: "12px 16px", borderTop: "1px solid #e5e7eb", display: "flex", gap: 10 }}>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && ask()}
            placeholder="Ask about lineage, impact, or schema…"
            style={{
              flex: 1, padding: "10px 14px", borderRadius: 24, border: "1px solid #d1d5db",
              fontSize: 13, outline: "none", color: "#111"
            }}
          />
          <button onClick={() => ask()}
            disabled={!query.trim() || loading}
            style={{
              padding: "10px 20px", borderRadius: 24, border: "none",
              background: (!query.trim() || loading) ? "#e5e7eb" : "#6366f1",
              color: (!query.trim() || loading) ? "#9ca3af" : "#fff",
              fontSize: 13, fontWeight: 600, cursor: (!query.trim() || loading) ? "not-allowed" : "pointer"
            }}>
            Send
          </button>
        </div>
      </Card>
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState(0);
  const [refreshKey, setRefreshKey] = useState(0);

  const TABS = [
    { label: "📄 SQL Metadata", component: <TabUpload key={refreshKey} onRefresh={() => setRefreshKey(k => k + 1)} /> },
    { label: "🕸 Lineage Graph", component: <TabLineage key={"lineage-" + refreshKey + "-" + tab} /> },
    { label: "⚡ Impact Simulator", component: <TabImpact key={refreshKey} /> },
    { label: "🤖 AI Q&A", component: <TabNLQA /> },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9", fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        * { box-sizing: border-box; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes bounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-6px); } }
        body { margin: 0; }
        select, input { font-family: inherit; }
      `}</style>

      {/* Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid #e5e7eb", padding: "0 32px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", gap: 16, height: 60 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 16
            }}>⚡</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: "#111" }}>EDW Impact Agent</div>
              <div style={{ fontSize: 11, color: "#9ca3af" }}>Data Lineage & Impact Analysis PoC</div>
            </div>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 4 }}>
            <span style={{ padding: "3px 10px", borderRadius: 20, background: "#d1fae5", color: "#065f46", fontSize: 11, fontWeight: 600 }}>● Live</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background: "#fff", borderBottom: "1px solid #e5e7eb" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 32px", display: "flex", gap: 0 }}>
          {TABS.map((t, i) => (
            <button key={i} onClick={() => setTab(i)}
              style={{
                padding: "14px 20px", border: "none", background: "none", cursor: "pointer",
                fontSize: 13, fontWeight: tab === i ? 600 : 400,
                color: tab === i ? "#6366f1" : "#6b7280",
                borderBottom: tab === i ? "2px solid #6366f1" : "2px solid transparent",
                transition: "all 0.15s"
              }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 32px" }}>
        {TABS[tab].component}
      </div>
    </div>
  );
}
