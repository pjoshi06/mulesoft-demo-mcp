import { useEffect, useState } from 'react'
import axios from 'axios'

const ISSUE_TYPES = [
  { value: 'schema_change', label: 'Schema change (column renamed/dropped)' },
  { value: 'data_type_change', label: 'Data type change' },
  { value: 'null_spike', label: 'NULL spike detected' },
  { value: 'pipeline_failure', label: 'Pipeline job failure' },
  { value: 'data_quality_breach', label: 'Data quality breach' },
]

const SEVERITY_COLORS = { HIGH: '#dc2626', MEDIUM: '#d97706', LOW: '#16a34a' }
const LAYER_COLORS = {
  EDW: { bg: '#dbeafe', border: '#2563eb', text: '#1e40af' },
  EDL: { bg: '#ede9fe', border: '#7c3aed', text: '#5b21b6' },
  ODS: { bg: '#d1fae5', border: '#059669', text: '#065f46' },
}

function renderMarkdown(text) {
  // Very simple markdown-to-HTML for the report
  return text
    .replace(/^## (.+)$/gm, '<h2 style="font-size:16px;margin:14px 0 6px;color:#0f172a">$1</h2>')
    .replace(/^### (.+)$/gm, '<h3 style="font-size:14px;margin:10px 0 4px;color:#1e293b">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.+?)`/g, '<code style="background:#f1f5f9;padding:1px 5px;border-radius:3px;font-family:monospace;font-size:12px">$1</code>')
    .replace(/^(\d+)\. (.+)$/gm, '<div style="padding:2px 0 2px 16px;font-size:13px"><strong>$1.</strong> $2</div>')
    .replace(/^- (.+)$/gm, '<div style="padding:2px 0 2px 12px;font-size:13px">• $1</div>')
    .replace(/\n/g, '<br/>')
}

export default function ImpactSimulator({ onImpact }) {
  const [tables, setTables] = useState([])
  const [selectedTable, setSelectedTable] = useState('')
  const [selectedColumn, setSelectedColumn] = useState('')
  const [issueType, setIssueType] = useState('schema_change')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [history, setHistory] = useState([])

  useEffect(() => {
    axios.get('/api/tables').then(({ data }) => {
      // Only EDW tables as source of issues
      const edwTables = data.filter(t => t.layer === 'EDW')
      setTables(data)
      if (edwTables.length) setSelectedTable(edwTables[0].name)
    })
    axios.get('/api/issues').then(({ data }) => setHistory(data.reverse()))
  }, [])

  const currentTableMeta = tables.find(t => t.name === selectedTable)

  const simulate = async () => {
    if (!selectedTable) return
    setLoading(true)
    setResult(null)
    try {
      const { data } = await axios.post('/api/simulate-impact', {
        table: selectedTable,
        column: selectedColumn || null,
        issue_type: issueType
      })
      setResult(data)
      onImpact && onImpact()
      // Refresh history
      const hist = await axios.get('/api/issues')
      setHistory(hist.data.reverse())
    } catch (e) {
      setResult({ error: e.response?.data?.detail || 'Simulation failed' })
    }
    setLoading(false)
  }

  return (
    <div style={{ display: 'flex', gap: 16, height: '72vh' }}>
      {/* Left - Controls */}
      <div style={{ width: 300, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="card">
          <h3 style={{ margin: '0 0 14px', fontSize: 15, color: '#0f172a' }}>Simulate EDW Issue</h3>

          <label className="form-label">Source table (EDW)</label>
          <select className="form-select" value={selectedTable} onChange={e => { setSelectedTable(e.target.value); setSelectedColumn('') }}>
            {tables.filter(t => t.layer === 'EDW').map(t => (
              <option key={t.name} value={t.name}>{t.name}</option>
            ))}
          </select>

          <label className="form-label" style={{ marginTop: 12 }}>Affected column (optional)</label>
          <select className="form-select" value={selectedColumn} onChange={e => setSelectedColumn(e.target.value)}>
            <option value="">— All columns / table-level —</option>
            {currentTableMeta?.columns?.map(c => (
              <option key={c.name} value={c.name}>{c.name}</option>
            ))}
          </select>

          <label className="form-label" style={{ marginTop: 12 }}>Issue type</label>
          <select className="form-select" value={issueType} onChange={e => setIssueType(e.target.value)}>
            {ISSUE_TYPES.map(i => <option key={i.value} value={i.value}>{i.label}</option>)}
          </select>

          <button
            onClick={simulate} disabled={loading || !selectedTable}
            style={{
              marginTop: 18, width: '100%', padding: '10px 0',
              background: loading ? '#94a3b8' : '#2563eb', color: '#fff',
              border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700,
              cursor: loading ? 'not-allowed' : 'pointer', transition: 'background 0.15s'
            }}>
            {loading ? 'Analyzing...' : 'Run Impact Analysis'}
          </button>
        </div>

        {/* History */}
        {history.length > 0 && (
          <div className="card" style={{ flex: 1, overflowY: 'auto' }}>
            <h3 style={{ margin: '0 0 10px', fontSize: 13, color: '#374151' }}>Recent Simulations</h3>
            {history.slice(0, 8).map(h => (
              <div key={h.id} style={{
                padding: '8px 10px', borderRadius: 6, marginBottom: 6,
                background: '#f8fafc', border: '1px solid #e2e8f0'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#1e293b' }}>{h.table}</span>
                  <span style={{
                    fontSize: 10, fontWeight: 700, color: '#fff',
                    background: SEVERITY_COLORS[h.severity], borderRadius: 3, padding: '1px 6px'
                  }}>{h.severity}</span>
                </div>
                <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>
                  {h.issue_type} • {h.impacted_count} tables affected
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Right - Results */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {!result && !loading && (
          <div style={{
            height: '100%', display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', color: '#94a3b8', textAlign: 'center'
          }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>&#9889;</div>
            <h3 style={{ margin: '0 0 8px', color: '#64748b' }}>Ready to simulate</h3>
            <p style={{ fontSize: 13 }}>Select an EDW table, optionally a column, choose an issue type, and run the analysis.</p>
          </div>
        )}

        {loading && (
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ textAlign: 'center', color: '#64748b' }}>
              <div className="spinner" />
              <p>Agent is analyzing blast radius...</p>
            </div>
          </div>
        )}

        {result && !result.error && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {/* Severity banner */}
            <div style={{
              padding: '14px 18px', borderRadius: 10,
              background: result.severity === 'HIGH' ? '#fef2f2' : result.severity === 'MEDIUM' ? '#fffbeb' : '#f0fdf4',
              border: `1.5px solid ${SEVERITY_COLORS[result.severity]}`,
              display: 'flex', alignItems: 'center', gap: 14
            }}>
              <span style={{ fontSize: 32 }}>
                {result.severity === 'HIGH' ? '🔴' : result.severity === 'MEDIUM' ? '🟡' : '🟢'}
              </span>
              <div>
                <div style={{ fontWeight: 700, fontSize: 16, color: SEVERITY_COLORS[result.severity] }}>
                  {result.severity} SEVERITY IMPACT
                </div>
                <div style={{ fontSize: 13, color: '#475569' }}>
                  {result.impacted_tables.length} downstream table(s) affected by {result.issue_type} on <code style={{ background: '#f1f5f9', padding: '0 4px', borderRadius: 3 }}>{result.source}{result.column ? '.' + result.column : ''}</code>
                </div>
              </div>
            </div>

            {/* Impacted tables visual */}
            {result.impacted_tables.length > 0 && (
              <div className="card">
                <h3 style={{ margin: '0 0 12px', fontSize: 14 }}>Blast Radius</h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                  {result.impacted_tables.map(t => {
                    const c = LAYER_COLORS[t.layer] || LAYER_COLORS.EDW
                    return (
                      <div key={t.table} style={{
                        background: c.bg, border: `1.5px solid ${c.border}`,
                        borderRadius: 8, padding: '8px 12px', minWidth: 160
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                          <span style={{ fontSize: 10, background: c.border, color: '#fff', borderRadius: 3, padding: '1px 5px', fontWeight: 700 }}>{t.layer}</span>
                          <span style={{ fontSize: 10, color: c.text }}>{t.distance} hop{t.distance > 1 ? 's' : ''}</span>
                        </div>
                        <div style={{ fontSize: 12, fontWeight: 700, color: c.text, wordBreak: 'break-all' }}>{t.table}</div>
                        {t.affected_columns?.length > 0 && (
                          <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
                            Cols: {t.affected_columns.slice(0, 3).join(', ')}{t.affected_columns.length > 3 ? '...' : ''}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* AI Report */}
            <div className="card">
              <h3 style={{ margin: '0 0 12px', fontSize: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span>&#129302;</span> Agent Analysis Report
              </h3>
              <div
                style={{ fontSize: 13, lineHeight: 1.7, color: '#334155' }}
                dangerouslySetInnerHTML={{ __html: renderMarkdown(result.report) }}
              />
            </div>
          </div>
        )}

        {result?.error && (
          <div className="card" style={{ background: '#fef2f2', border: '1.5px solid #dc2626' }}>
            <p style={{ color: '#dc2626', margin: 0 }}>Error: {result.error}</p>
          </div>
        )}
      </div>
    </div>
  )
}
