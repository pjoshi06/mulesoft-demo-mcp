import { useEffect, useState, useCallback } from 'react'
import axios from 'axios'
import {
  ReactFlow, Background, Controls, MiniMap,
  useNodesState, useEdgesState, Handle, Position
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'

const LAYER_COLORS = {
  EDW: { bg: '#dbeafe', border: '#2563eb', text: '#1e40af', badge: '#2563eb' },
  EDL: { bg: '#ede9fe', border: '#7c3aed', text: '#5b21b6', badge: '#7c3aed' },
  ODS: { bg: '#d1fae5', border: '#059669', text: '#065f46', badge: '#059669' },
  UNKNOWN: { bg: '#f3f4f6', border: '#6b7280', text: '#374151', badge: '#6b7280' },
}

function TableNode({ data }) {
  const c = LAYER_COLORS[data.layer] || LAYER_COLORS.UNKNOWN
  return (
    <div style={{
      background: c.bg, border: `2px solid ${c.border}`,
      borderRadius: 10, padding: '10px 14px', minWidth: 180,
      boxShadow: '0 2px 8px rgba(0,0,0,0.10)'
    }}>
      <Handle type="target" position={Position.Left} style={{ background: c.border }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <span style={{
          background: c.badge, color: '#fff', fontSize: 10,
          borderRadius: 4, padding: '1px 6px', fontWeight: 700, letterSpacing: 0.5
        }}>{data.layer}</span>
      </div>
      <div style={{ fontWeight: 700, color: c.text, fontSize: 13, wordBreak: 'break-all' }}>
        {data.label}
      </div>
      <div style={{ color: '#64748b', fontSize: 11, marginTop: 3 }}>
        {data.columns} column{data.columns !== 1 ? 's' : ''}
      </div>
      <Handle type="source" position={Position.Right} style={{ background: c.border }} />
    </div>
  )
}

const nodeTypes = { tableNode: TableNode }

export default function LineageGraph() {
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    axios.get('/api/lineage-graph').then(({ data }) => {
      // Better layout: spread nodes vertically per layer
      const layerX = { EDW: 80, EDL: 380, ODS: 680, UNKNOWN: 80 }
      const layerCounts = {}
      const positioned = data.nodes.map(n => {
        const lyr = n.data.layer
        layerCounts[lyr] = (layerCounts[lyr] || 0) + 1
        return { ...n, position: { x: layerX[lyr] || 80, y: (layerCounts[lyr] - 1) * 130 + 60 } }
      })
      setNodes(positioned)
      setEdges(data.edges.map(e => ({
        ...e, type: 'smoothstep', animated: true,
        style: { stroke: '#94a3b8', strokeWidth: 2 }
      })))
      setLoading(false)
    })
  }, [])

  const onNodeClick = useCallback((_, node) => setSelected(node.data), [])

  return (
    <div style={{ display: 'flex', height: '70vh', gap: 16 }}>
      <div style={{ flex: 1, borderRadius: 12, border: '1px solid #e2e8f0', overflow: 'hidden', background: '#f8fafc' }}>
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#64748b' }}>
            Loading lineage graph...
          </div>
        ) : (
          <ReactFlow
            nodes={nodes} edges={edges}
            onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView fitViewOptions={{ padding: 0.2 }}
          >
            <Background color="#e2e8f0" gap={20} />
            <Controls />
            <MiniMap nodeColor={n => LAYER_COLORS[n.data?.layer]?.border || '#6b7280'} />
          </ReactFlow>
        )}
      </div>

      <div style={{ width: 260, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Legend */}
        <div className="card">
          <h3 style={{ margin: '0 0 12px', fontSize: 14, color: '#374151' }}>Layer Legend</h3>
          {Object.entries(LAYER_COLORS).filter(([k]) => k !== 'UNKNOWN').map(([layer, c]) => (
            <div key={layer} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <div style={{ width: 14, height: 14, borderRadius: 3, background: c.bg, border: `2px solid ${c.border}` }} />
              <span style={{ fontSize: 13, color: '#374151', fontWeight: 600 }}>{layer}</span>
              <span style={{ fontSize: 11, color: '#64748b' }}>
                {layer === 'EDW' ? 'Source' : layer === 'EDL' ? 'Enterprise Data Lake' : 'Operational Store'}
              </span>
            </div>
          ))}
        </div>

        {/* Node detail */}
        {selected && (
          <div className="card">
            <h3 style={{ margin: '0 0 10px', fontSize: 14, color: '#374151' }}>Selected Table</h3>
            <div style={{ marginBottom: 6 }}>
              <span style={{
                background: LAYER_COLORS[selected.layer]?.badge,
                color: '#fff', fontSize: 10, borderRadius: 4,
                padding: '1px 6px', fontWeight: 700
              }}>{selected.layer}</span>
            </div>
            <div style={{ fontWeight: 700, fontSize: 14, color: '#1e293b', marginBottom: 4, wordBreak: 'break-all' }}>
              {selected.label}
            </div>
            <div style={{ fontSize: 12, color: '#64748b' }}>{selected.columns} columns registered</div>
          </div>
        )}

        <div className="card" style={{ background: '#fffbeb', border: '1px solid #fbbf24' }}>
          <p style={{ margin: 0, fontSize: 12, color: '#92400e' }}>
            <strong>Tip:</strong> Click any node to see details. Arrows show data flow direction (left to right). Upload more SQL scripts to extend the graph.
          </p>
        </div>
      </div>
    </div>
  )
}
