import { useState, useRef, useEffect } from 'react'
import axios from 'axios'

const SUGGESTIONS = [
  "What breaks if I drop the customer_id column?",
  "How do NULL values propagate through the pipeline?",
  "What happens with a schema change in EDW?",
  "Who owns the downstream tables?",
  "How is lineage tracked at the column level?",
  "What is the blast radius of a pipeline failure?",
]

function renderMarkdown(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.+?)`/g, '<code style="background:#f1f5f9;padding:1px 5px;border-radius:3px;font-family:monospace;font-size:12px;color:#0f172a">$1</code>')
    .replace(/^(\d+)\. (.+)$/gm, '<div style="padding:3px 0 3px 16px"><strong>$1.</strong> $2</div>')
    .replace(/^- (.+)$/gm, '<div style="padding:2px 0 2px 12px">• $1</div>')
    .replace(/\n/g, '<br/>')
}

export default function NLQAgent() {
  const [messages, setMessages] = useState([
    {
      role: 'agent',
      text: "Hi! I'm the EDW Impact Analysis Agent. Ask me anything about your data pipeline — schema changes, impact analysis, lineage, or data quality risks."
    }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async (q) => {
    const question = q || input.trim()
    if (!question) return
    setMessages(m => [...m, { role: 'user', text: question }])
    setInput('')
    setLoading(true)
    try {
      const { data } = await axios.post('/api/ask', { question })
      setMessages(m => [...m, { role: 'agent', text: data.answer }])
    } catch (e) {
      setMessages(m => [...m, { role: 'agent', text: 'Sorry, I encountered an error. Please try again.' }])
    }
    setLoading(false)
  }

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
  }

  return (
    <div style={{ display: 'flex', gap: 16, height: '72vh' }}>
      {/* Chat window */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 0 }}>
        {/* Messages */}
        <div style={{
          flex: 1, overflowY: 'auto', padding: '16px',
          background: '#f8fafc', borderRadius: '12px 12px 0 0',
          border: '1px solid #e2e8f0', borderBottom: 'none'
        }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start',
              marginBottom: 14
            }}>
              {m.role === 'agent' && (
                <div style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: '#2563eb', color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 16, flexShrink: 0, marginRight: 10, marginTop: 2
                }}>&#129302;</div>
              )}
              <div style={{
                maxWidth: '78%', padding: '10px 14px', borderRadius: 12,
                background: m.role === 'user' ? '#2563eb' : '#fff',
                color: m.role === 'user' ? '#fff' : '#1e293b',
                border: m.role === 'agent' ? '1px solid #e2e8f0' : 'none',
                fontSize: 13, lineHeight: 1.65,
                boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
              }}>
                {m.role === 'user'
                  ? m.text
                  : <div dangerouslySetInnerHTML={{ __html: renderMarkdown(m.text) }} />
                }
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%',
                background: '#2563eb', color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16
              }}>&#129302;</div>
              <div style={{
                padding: '10px 14px', borderRadius: 12, background: '#fff',
                border: '1px solid #e2e8f0', color: '#64748b', fontSize: 13
              }}>
                Thinking...
                <span style={{ display: 'inline-block', animation: 'pulse 1s infinite' }}>&#8230;</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{
          display: 'flex', gap: 10, padding: 12,
          background: '#fff', border: '1px solid #e2e8f0',
          borderRadius: '0 0 12px 12px'
        }}>
          <textarea
            value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
            placeholder="Ask about impact, lineage, schema changes..."
            rows={2}
            style={{
              flex: 1, border: '1px solid #e2e8f0', borderRadius: 8,
              padding: '8px 12px', fontSize: 13, resize: 'none',
              fontFamily: 'inherit', outline: 'none'
            }}
          />
          <button onClick={() => send()} disabled={loading || !input.trim()}
            style={{
              padding: '0 20px', background: '#2563eb', color: '#fff',
              border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700,
              cursor: loading || !input.trim() ? 'not-allowed' : 'pointer',
              opacity: loading || !input.trim() ? 0.5 : 1
            }}>Send</button>
        </div>
      </div>

      {/* Suggestions sidebar */}
      <div style={{ width: 240, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="card">
          <h3 style={{ margin: '0 0 12px', fontSize: 13, color: '#374151' }}>Suggested Questions</h3>
          {SUGGESTIONS.map((s, i) => (
            <button key={i} onClick={() => send(s)}
              style={{
                display: 'block', width: '100%', textAlign: 'left',
                padding: '8px 10px', marginBottom: 6,
                background: '#f8fafc', border: '1px solid #e2e8f0',
                borderRadius: 7, fontSize: 12, color: '#374151',
                cursor: 'pointer', lineHeight: 1.4,
                transition: 'background 0.15s'
              }}
              onMouseEnter={e => e.target.style.background = '#e0e7ff'}
              onMouseLeave={e => e.target.style.background = '#f8fafc'}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="card" style={{ background: '#eff6ff', border: '1px solid #bfdbfe' }}>
          <p style={{ margin: 0, fontSize: 12, color: '#1e40af', lineHeight: 1.5 }}>
            <strong>PoC mode:</strong> Responses are pre-scripted for demo purposes. In production, this connects to a live LLM with full metadata context.
          </p>
        </div>
      </div>
    </div>
  )
}
