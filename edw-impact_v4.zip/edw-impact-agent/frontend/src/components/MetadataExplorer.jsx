import { useEffect, useState } from 'react'
import axios from 'axios'

const LAYER_COLORS = {
  EDW: { bg: '#dbeafe', text: '#1e40af', border: '#2563eb' },
  EDL: { bg: '#ede9fe', text: '#5b21b6', border: '#7c3aed' },
  ODS: { bg: '#d1fae5', text: '#065f46', border: '#059669' },
  UNKNOWN: { bg: '#f3f4f6', text: '#374151', border: '#6b7280' },
}

export default function MetadataExplorer() {
  const [tables, setTables] = useState([])
  const [selected, setSelected] = useState(null)
  const [search, setSearch] = useState('')
  const [layerFilter, setLayerFilter] = useState('ALL')

  useEffect(() => {
    axios.get('/api/tables').then(({ data }) => {
      setTables(data)
      if (data.length) setSelected(data[0])
    })
  }, [])

  const filtered = tables.filter(t => {
    const matchSearch = t.name.toLowerCase().includes(search.toLowerCase())
    const matchLayer = layerFilter === 'ALL' || t.layer === layerFilter
    return matchSearch && matchLayer
  })

  return (
    <div style={{ display: 'flex', height: '72vh', gap: 16 }}>
      {/* Left panel - table list */}
      <div style={{ width: 280, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <input
          placeholder="Search tables..."
          value={search} onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        <div style={{ display: 'flex', gap: 6 }}>
          {['ALL', 'EDW', 'EDL', 'ODS'].map(l => (
            <button key={l} onClick={() => setLayerFilter(l)}
              style={{
                flex: 1, padding: '4px 0', fontSize: 11, fontWeight: 700,
                border: `1.5px solid ${layerFilter === l ? '#2563eb' : '#e2e8f0'}`,
                background: layerFilter === l ? '#2563eb' : '#fff',
                color: layerFilter === l ? '#fff' : '#374151',
                borderRadius: 6, cursor: 'pointer'
              }}>
              {l}
            </button>
          ))}
        </div>
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {filtered.map(t => {
            const c = LAYER_COLORS[t.layer] || LAYER_COLORS.UNKNOWN
            return (
              <div key={t.name}
                onClick={() => setSelected(t)}
                style={{
                  padding: '10px 12px', borderRadius: 8, cursor: 'pointer',
                  background: selected?.name === t.name ? c.bg : '#fff',
                  border: `1.5px solid ${selected?.name === t.name ? c.border : '#e2e8f0'}`,
                  transition: 'all 0.15s'
                }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                  <span style={{
                    background: c.border, color: '#fff', fontSize: 9,
                    borderRadius: 3, padding: '1px 5px', fontWeight: 700
                  }}>{t.layer}</span>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#1e293b', wordBreak: 'break-all' }}>{t.name}</div>
                <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>{t.column_count} columns</div>
              </div>
            )
          })}
        </div>
        <div style={{ fontSize: 11, color: '#94a3b8', textAlign: 'center' }}>{filtered.length} of {tables.length} tables</div>
      </div>

      {/* Right panel - table detail */}
      {selected ? (
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Header */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <span style={{
                background: LAYER_COLORS[selected.layer]?.border,
                color: '#fff', fontSize: 12, borderRadius: 5,
                padding: '2px 10px', fontWeight: 700
              }}>{selected.layer}</span>
              <h2 style={{ margin: 0, fontSize: 18, color: '#0f172a' }}>{selected.name}</h2>
            </div>
            <div style={{ display: 'flex', gap: 24 }}>
              <div><span style={{ fontSize: 12, color: '#64748b' }}>Columns</span><br /><strong>{selected.column_count}</strong></div>
              <div><span style={{ fontSize: 12, color: '#64748b' }}>Source tables</span><br /><strong>{selected.source_tables?.length || 0}</strong></div>
              <div><span style={{ fontSize: 12, color: '#64748b' }}>Parsed from</span><br /><strong style={{ fontSize: 12 }}>{selected.filename}</strong></div>
            </div>
          </div>

          {/* Source dependencies */}
          {selected.source_tables?.length > 0 && (
            <div className="card">
              <h3 style={{ margin: '0 0 10px', fontSize: 14 }}>Upstream Dependencies</h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {selected.source_tables.map(src => {
                  const lyr = src.startsWith('edw.') ? 'EDW' : src.startsWith('edl.') ? 'EDL' : 'EDW'
                  const c = LAYER_COLORS[lyr]
                  return (
                    <span key={src} style={{
                      background: c.bg, border: `1px solid ${c.border}`,
                      color: c.text, fontSize: 12, borderRadius: 6,
                      padding: '4px 10px', fontWeight: 600
                    }}>
                      {src}
                    </span>
                  )
                })}
              </div>
            </div>
          )}

          {/* Columns */}
          <div className="card">
            <h3 style={{ margin: '0 0 12px', fontSize: 14 }}>Column Lineage</h3>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ background: '#f8fafc' }}>
                  {['Target column', 'Source table', 'Source column', 'Transform'].map(h => (
                    <th key={h} style={{ textAlign: 'left', padding: '8px 10px', fontSize: 11, color: '#64748b', fontWeight: 600, borderBottom: '1px solid #e2e8f0' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {selected.columns?.map((col, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '8px 10px', fontWeight: 600, color: '#1e293b', fontFamily: 'monospace' }}>{col.name}</td>
                    <td style={{ padding: '8px 10px', color: '#64748b', fontSize: 12 }}>{col.source_table || '—'}</td>
                    <td style={{ padding: '8px 10px', color: '#64748b', fontFamily: 'monospace', fontSize: 12 }}>{col.source_col || '—'}</td>
                    <td style={{ padding: '8px 10px' }}>
                      <span style={{
                        background: col.transform === 'direct' ? '#dcfce7' : '#fef3c7',
                        color: col.transform === 'direct' ? '#166534' : '#92400e',
                        fontSize: 11, borderRadius: 4, padding: '2px 7px', fontWeight: 600
                      }}>
                        {col.transform || 'direct'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>
          Select a table to explore its metadata
        </div>
      )}
    </div>
  )
}
