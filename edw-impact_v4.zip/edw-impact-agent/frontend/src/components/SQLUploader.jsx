import { useState, useEffect } from 'react'
import axios from 'axios'

export default function SQLUploader({ onUpload }) {
  const [samples, setSamples] = useState([])
  const [loaded, setLoaded] = useState({})
  const [uploading, setUploading] = useState(false)
  const [uploadResult, setUploadResult] = useState(null)
  const [dragOver, setDragOver] = useState(false)
  const [previewSql, setPreviewSql] = useState(null)

  const SAMPLE_PREVIEWS = {
    'edl_customer.sql': 'EDW customers → EDL customer_profile (10 columns)',
    'edl_accounts.sql': 'EDW accounts + customers → EDL account_summary (11 columns + CASE WHEN)',
    'edl_transactions.sql': 'EDW transactions + accounts + products + fx_rates → EDL transaction_detail',
    'ods_customer_360.sql': 'EDL customer_profile + account_summary + transaction_detail → ODS customer_360',
    'ods_account_risk.sql': 'EDL account_summary + transaction_detail → ODS account_risk',
  }

  useEffect(() => {
    axios.get('/api/samples').then(({ data }) => setSamples(data))
  }, [])

  const loadSample = async (fname) => {
    setLoaded(l => ({ ...l, [fname]: 'loading' }))
    try {
      await axios.post(`/api/load-sample/${fname}`)
      setLoaded(l => ({ ...l, [fname]: 'done' }))
      onUpload && onUpload()
    } catch {
      setLoaded(l => ({ ...l, [fname]: 'error' }))
    }
  }

  const handleFileUpload = async (file) => {
    if (!file || !file.name.endsWith('.sql')) {
      setUploadResult({ error: 'Please upload a .sql file' })
      return
    }
    setUploading(true)
    setUploadResult(null)
    const form = new FormData()
    form.append('file', file)
    try {
      const { data } = await axios.post('/api/upload-sql', form)
      setUploadResult({ success: true, message: data.message, tables: data.tables })
      onUpload && onUpload()
    } catch (e) {
      setUploadResult({ error: e.response?.data?.detail || 'Upload failed' })
    }
    setUploading(false)
  }

  const onFileInput = (e) => handleFileUpload(e.target.files[0])
  const onDrop = (e) => {
    e.preventDefault(); setDragOver(false)
    handleFileUpload(e.dataTransfer.files[0])
  }

  return (
    <div style={{ display: 'flex', gap: 20 }}>
      {/* Pre-loaded samples */}
      <div style={{ flex: 1 }}>
        <div className="card">
          <h2 style={{ margin: '0 0 4px', fontSize: 16 }}>Pre-loaded Sample Scripts</h2>
          <p style={{ margin: '0 0 16px', fontSize: 13, color: '#64748b' }}>
            These scripts simulate a real EDW → EDL → ODS pipeline. Click to load each one into the metadata store.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {samples.map(fname => {
              const state = loaded[fname]
              const layer = fname.startsWith('edl') ? 'EDL' : fname.startsWith('ods') ? 'ODS' : 'EDW'
              const layerColor = { EDL: '#7c3aed', ODS: '#059669', EDW: '#2563eb' }[layer]

              return (
                <div key={fname} style={{
                  border: '1px solid #e2e8f0', borderRadius: 10, padding: '12px 16px',
                  background: state === 'done' ? '#f0fdf4' : '#fff',
                  borderColor: state === 'done' ? '#86efac' : '#e2e8f0',
                  transition: 'all 0.2s'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{
                        background: layerColor, color: '#fff', fontSize: 10,
                        borderRadius: 4, padding: '2px 7px', fontWeight: 700
                      }}>{layer}</span>
                      <span style={{ fontWeight: 600, fontSize: 14, fontFamily: 'monospace', color: '#1e293b' }}>{fname}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => setPreviewSql(previewSql === fname ? null : fname)}
                        style={{
                          padding: '5px 12px', fontSize: 12, borderRadius: 6,
                          border: '1px solid #e2e8f0', background: '#f8fafc',
                          cursor: 'pointer', color: '#374151'
                        }}>
                        {previewSql === fname ? 'Hide' : 'Preview'}
                      </button>
                      <button
                        onClick={() => loadSample(fname)}
                        disabled={state === 'loading' || state === 'done'}
                        style={{
                          padding: '5px 16px', fontSize: 12, fontWeight: 700, borderRadius: 6,
                          border: 'none', cursor: state === 'done' ? 'default' : 'pointer',
                          background: state === 'done' ? '#16a34a' : state === 'loading' ? '#94a3b8' : '#2563eb',
                          color: '#fff', transition: 'background 0.15s'
                        }}>
                        {state === 'done' ? '✓ Loaded' : state === 'loading' ? 'Loading...' : 'Load'}
                      </button>
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
                    {SAMPLE_PREVIEWS[fname]}
                  </div>
                </div>
              )
            })}
          </div>

          <button
            onClick={() => samples.forEach(s => loadSample(s))}
            style={{
              marginTop: 16, width: '100%', padding: '10px 0',
              background: '#7c3aed', color: '#fff', border: 'none',
              borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: 'pointer'
            }}>
            Load All Samples at Once
          </button>
        </div>
      </div>

      {/* Upload section */}
      <div style={{ width: 320, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="card">
          <h2 style={{ margin: '0 0 4px', fontSize: 16 }}>Upload Your SQL</h2>
          <p style={{ margin: '0 0 14px', fontSize: 13, color: '#64748b' }}>
            Upload any CREATE TABLE AS SELECT script to extract metadata automatically.
          </p>

          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            style={{
              border: `2px dashed ${dragOver ? '#2563eb' : '#cbd5e1'}`,
              borderRadius: 10, padding: '30px 20px', textAlign: 'center',
              background: dragOver ? '#eff6ff' : '#f8fafc',
              transition: 'all 0.2s', cursor: 'pointer'
            }}
            onClick={() => document.getElementById('sql-upload').click()}
          >
            <div style={{ fontSize: 32, marginBottom: 8 }}>&#128196;</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#374151', marginBottom: 4 }}>
              Drop .sql file here
            </div>
            <div style={{ fontSize: 12, color: '#94a3b8' }}>or click to browse</div>
            <input id="sql-upload" type="file" accept=".sql" onChange={onFileInput} style={{ display: 'none' }} />
          </div>

          {uploading && (
            <div style={{ marginTop: 14, textAlign: 'center', color: '#64748b', fontSize: 13 }}>
              Parsing SQL and extracting metadata...
            </div>
          )}

          {uploadResult && (
            <div style={{
              marginTop: 14, padding: '12px 14px', borderRadius: 8,
              background: uploadResult.error ? '#fef2f2' : '#f0fdf4',
              border: `1px solid ${uploadResult.error ? '#fca5a5' : '#86efac'}`
            }}>
              {uploadResult.error ? (
                <p style={{ margin: 0, fontSize: 13, color: '#dc2626' }}>Error: {uploadResult.error}</p>
              ) : (
                <>
                  <p style={{ margin: '0 0 8px', fontSize: 13, fontWeight: 600, color: '#166534' }}>
                    {uploadResult.message}
                  </p>
                  {uploadResult.tables?.map(t => (
                    <div key={t} style={{ fontSize: 12, color: '#15803d', fontFamily: 'monospace' }}>✓ {t}</div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        <div className="card" style={{ background: '#fffbeb', border: '1px solid #fbbf24' }}>
          <h3 style={{ margin: '0 0 8px', fontSize: 13 }}>Supported SQL patterns</h3>
          <ul style={{ margin: 0, paddingLeft: 16, fontSize: 12, color: '#92400e', lineHeight: 1.8 }}>
            <li>CREATE TABLE AS SELECT</li>
            <li>Direct column references (t.col)</li>
            <li>CASE WHEN expressions</li>
            <li>COALESCE, UPPER, ROUND</li>
            <li>JOINs (INNER, LEFT, RIGHT)</li>
            <li>CTEs and subqueries (partial)</li>
            <li>Multi-dialect (Hive, Spark, standard)</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
