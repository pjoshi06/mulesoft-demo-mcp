#!/bin/bash
echo "Starting EDW Impact Agent backend on http://localhost:8000"
cd "$(dirname "$0")/backend"
uvicorn main:app --reload --port 8000
