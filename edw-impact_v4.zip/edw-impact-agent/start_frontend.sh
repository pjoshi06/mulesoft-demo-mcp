#!/bin/bash
echo "Starting EDW Impact Agent frontend on http://localhost:5173"
cd "$(dirname "$0")/frontend"
npm run dev
