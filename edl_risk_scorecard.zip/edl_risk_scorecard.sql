-- ============================================================
-- EDL: Risk Scorecard
-- Multi-hop transformation demonstrating:
--   Hop 1: EDW.CUSTOMER + EDW.ACCOUNT + EDW.CREDIT_HISTORY
--           -> EDL.RISK_SCORECARD
--
-- Transformations used:
--   CASE WHEN   (risk banding)
--   COALESCE    (null-safe defaults)
--   CAST        (type conversion)
--   DATEDIFF    (derived age from DOB)
--   Aggregation (delinquency counts from credit history)
-- ============================================================

CREATE TABLE EDL.RISK_SCORECARD AS

WITH credit_summary AS (
    -- Aggregate credit history per customer
    SELECT
        ch.customer_id,
        COUNT(ch.delinquency_flag)                          AS total_delinquencies,
        SUM(CASE WHEN ch.delinquency_flag = 1 THEN 1 ELSE 0 END) AS active_delinquencies,
        MAX(ch.outstanding_balance)                         AS max_outstanding_balance,
        AVG(ch.credit_utilisation_pct)                      AS avg_credit_utilisation,
        MIN(ch.credit_open_date)                            AS earliest_credit_date
    FROM EDW.CREDIT_HISTORY ch
    GROUP BY ch.customer_id
),

account_summary AS (
    -- Aggregate account-level exposure per customer
    SELECT
        a.customer_id,
        COUNT(a.account_id)                                 AS total_accounts,
        SUM(COALESCE(a.credit_limit, 0))                    AS total_credit_limit,
        SUM(COALESCE(a.current_balance, 0))                 AS total_current_balance,
        MAX(a.account_type)                                 AS primary_account_type,
        SUM(CASE WHEN a.account_status = 'OVERDUE'
                 THEN 1 ELSE 0 END)                         AS overdue_accounts
    FROM EDW.ACCOUNT a
    GROUP BY a.customer_id
)

SELECT
    -- Identity
    c.customer_id,
    c.first_name,
    c.last_name,
    c.country_code,
    c.segment_code,

    -- Derived age (hop: DOB -> integer years)
    CAST(DATEDIFF('year', c.date_of_birth, CURRENT_DATE) AS INT)    AS customer_age,

    -- Account exposure
    COALESCE(accs.total_accounts, 0)                                 AS total_accounts,
    COALESCE(accs.total_credit_limit, 0)                             AS total_credit_limit,
    COALESCE(accs.total_current_balance, 0)                          AS total_current_balance,
    COALESCE(accs.overdue_accounts, 0)                               AS overdue_accounts,
    accs.primary_account_type,

    -- Credit risk signals
    COALESCE(cs.total_delinquencies, 0)                              AS total_delinquencies,
    COALESCE(cs.active_delinquencies, 0)                             AS active_delinquencies,
    COALESCE(cs.max_outstanding_balance, 0)                          AS max_outstanding_balance,
    CAST(COALESCE(cs.avg_credit_utilisation, 0) AS DECIMAL(5,2))    AS avg_credit_utilisation,

    -- Derived: utilisation ratio (balance / limit)
    CASE
        WHEN COALESCE(accs.total_credit_limit, 0) = 0 THEN 0
        ELSE CAST(
            accs.total_current_balance / accs.total_credit_limit
            AS DECIMAL(5,4))
    END                                                              AS utilisation_ratio,

    -- Risk band (CASE transformation)
    CASE
        WHEN COALESCE(cs.active_delinquencies, 0) > 3
          OR COALESCE(accs.overdue_accounts, 0)  > 2    THEN 'VERY_HIGH'
        WHEN COALESCE(cs.active_delinquencies, 0) > 1
          OR COALESCE(accs.overdue_accounts, 0)  > 0    THEN 'HIGH'
        WHEN COALESCE(cs.avg_credit_utilisation, 0) > 75 THEN 'MEDIUM'
        WHEN COALESCE(cs.avg_credit_utilisation, 0) > 40 THEN 'LOW'
        ELSE 'VERY_LOW'
    END                                                              AS risk_band,

    -- Composite score (weighted, CAST to integer 0-1000)
    CAST(
        LEAST(1000,
            GREATEST(0,
                1000
                - (COALESCE(cs.active_delinquencies, 0)   * 120)
                - (COALESCE(accs.overdue_accounts, 0)      * 80)
                - (COALESCE(cs.avg_credit_utilisation, 0)  * 2)
                + (CASE WHEN c.segment_code = 'PREMIUM' THEN 50 ELSE 0 END)
            )
        )
    AS INT)                                                          AS composite_score,

    -- Existing EDW risk score (pass-through for comparison)
    CAST(c.risk_score AS DECIMAL(5,2))                               AS edw_risk_score

FROM EDW.CUSTOMER c
LEFT JOIN account_summary  accs ON c.customer_id = accs.customer_id
LEFT JOIN credit_summary   cs   ON c.customer_id = cs.customer_id
WHERE c.customer_status = 'ACTIVE';
